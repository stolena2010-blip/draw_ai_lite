"""
חילוץ נתונים משרטוט PDF — מודול ראשי של DrawingAI Lite.
עם Cost Tracking + OCR Fallback.
"""
import json
import logging
import re
from pathlib import Path

from core.azure_client import (
    get_client,
    get_deployment,
    is_reasoning_model,
    get_fallback_client_and_deployment,
)
from core.pdf_utils import pdf_to_images
from core.prompts import STAGE_1_PROMPT, STAGE_2_PROMPT, STAGE_3_PROMPT_TEMPLATE
from core.cost_tracker import DrawingCostTracker, calculate_cost
from core.master_matcher import match_all_coatings
from core.ocr_fallback import (
    is_ocr_available,
    extract_text_from_pdf,
    should_use_fallback,
    build_enhanced_prompt,
)

logger = logging.getLogger(__name__)


def _build_kwargs(max_tokens: int, temperature: float, json_mode: bool,
                  model: str | None = None) -> dict:
    """בונה kwargs מתאימים למודל הפעיל (reasoning vs רגיל)."""
    kwargs: dict = {}
    if is_reasoning_model(model):
        kwargs["max_completion_tokens"] = max_tokens
        # reasoning models — אין temperature, ואין response_format=json_object בכל הגרסאות
    else:
        kwargs["max_tokens"] = max_tokens
        kwargs["temperature"] = temperature
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}
    return kwargs


def _call_vision(client, deployment: str, prompt: str, images_b64: list[str],
                 model: str | None = None):
    """קריאה ל-Vision API. מחזיר (result_dict, usage)."""
    content = [{"type": "text", "text": prompt}]
    for img_b64 in images_b64:
        content.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:image/png;base64,{img_b64}",
                "detail": "high",
            },
        })

    # reasoning models אוכלים הרבה טוקנים ב"חשיבה"; תקצה בנדיבות
    budget = 16000 if is_reasoning_model(model) else 4000

    response = client.chat.completions.create(
        model=deployment,
        messages=[{"role": "user", "content": content}],
        **_build_kwargs(max_tokens=budget, temperature=0.1, json_mode=True, model=model),
    )

    raw = (response.choices[0].message.content or "").strip()
    # reasoning models לפעמים עוטפים את ה-JSON — חלץ
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()
    if not raw:
        # תוצאה ריקה — ככל הנראה חסימת tokens על reasoning
        logger.warning(
            "Vision call returned empty content (finish_reason=%s, usage=%s)",
            getattr(response.choices[0], "finish_reason", "?"),
            getattr(response, "usage", None),
        )
        return {}, response.usage
    try:
        result = json.loads(raw)
    except json.JSONDecodeError as exc:
        logger.warning("JSON parse failed: %s — raw head: %s", exc, raw[:200])
        return {}, response.usage
    return result, response.usage


def _call_text(client, deployment: str, prompt: str, model: str | None = None):
    """קריאה טקסטואלית. מחזיר (text, usage)."""
    response = client.chat.completions.create(
        model=deployment,
        messages=[{"role": "user", "content": prompt}],
        **_build_kwargs(max_tokens=400, temperature=0.3, json_mode=False, model=model),
    )
    return (response.choices[0].message.content or "").strip(), response.usage


def _safe_call(call_fn, client, deployment, *extra_args):
    """מריץ קריאה מול המודל הראשי. אם נכשל ויש fallback — מנסה מולו."""
    try:
        return call_fn(client, deployment, *extra_args)
    except Exception as primary_exc:
        fb_client, fb_deployment, fb_model = get_fallback_client_and_deployment()
        if fb_client is None:
            raise
        logger.warning(
            "⚠️ קריאה למודל הראשי נכשלה (%s) — עובר ל-fallback: %s",
            primary_exc, fb_model,
        )
        return call_fn(fb_client, fb_deployment, *extra_args, model=fb_model)


_MATERIAL_RE = re.compile(
    r"MATERIAL[:\s]+([A-Z0-9][A-Z0-9 \-./]*?)(?=[.\n]|$)",
    re.IGNORECASE,
)


def _extract_material_from_notes(notes: str) -> str:
    """Fallback — מוצא 'MATERIAL ...' בתוך טקסט ה-NOTES."""
    if not notes:
        return ""
    m = _MATERIAL_RE.search(notes)
    if not m:
        return ""
    return m.group(1).strip(" .,-")


# מילות מפתח לזיהוי שציפוי צריך להיות מזוהה אבל Stage 2 פספס
_COATING_KEYWORDS_RE = re.compile(
    r"\b(CONVERSION COATING|ALODINE|IRIDITE|CHEM FILM|CHROMATE|"
    r"ANODIZE|ANODIZING|ANODIC|"
    r"PASSIVAT|ELECTROLESS|NICKEL PLAT|ZINC PLAT|CADMIUM|CHROME PLAT|"
    r"TIN PLAT|SILVER PLAT|GOLD PLAT|COPPER PLAT|"
    r"BLACK OXIDE|PHOSPHAT|"
    r"MIL-?C-?5541|MIL-?DTL-?5541|MIL-?A-?8625|MIL-?C-?26074|"
    r"ASTM B633|ASTM B733|QQ-?N-?290|QQ-?P-?416|QQ-?Z-?325)\b",
    re.IGNORECASE,
)


def _notes_hint_coating(stage1: dict, stage2: dict) -> bool:
    """האם ב-NOTES של stage1/stage2 מופיעות מילות מפתח של ציפוי?"""
    text = " ".join([
        str(stage1.get("notes") or ""),
        str(stage2.get("notes") or ""),
    ])
    return bool(_COATING_KEYWORDS_RE.search(text))


# מספר פריט לרוב: 5-15 תווים, אותיות+ספרות, אופציונלי מקפים פנימיים
# Whitelist של prefixes מוכרים של לקוחות — מקבלים עדיפות
_KNOWN_PN_PREFIXES = (
    "PWRL", "BBLE", "HLTA", "FTLS", "FTL",  # RAFAEL
    "BG", "BO", "RF",                        # RAFAEL קצרים
    "BP",                                    # B2B / Aerospace
    "IAI",                                   # Israel Aerospace
    "EL",                                    # Elbit
)
# Blacklist של מחרוזות שאסור לקחת (false positives נפוצים)
_PN_BLACKLIST = {"CAGE", "DWG", "DRAW", "DATE", "NOTES", "QTY", "SIZE",
                 "REV", "SHEET", "SCALE", "TOLERANCE", "FINISH"}

_PN_PATTERN = re.compile(r"\b([A-Z]{2,4}[A-Z0-9]{0,3}\d{2,}[A-Z0-9]*)\b")


def _extract_pn_from_filename(filename: str) -> str:
    """מנסה למצוא מספר פריט בשם הקובץ (זהיר — מסנן blacklist + עדיפות whitelist)."""
    if not filename:
        return ""
    stem = Path(filename).stem.upper()
    # ננקה תחיליות שכיחות
    for prefix in ("B2BDRAW_", "DRAW_", "_"):
        if stem.startswith(prefix):
            stem = stem[len(prefix):]
    # פיצול לסגמנטים לפי מקף, קו תחתון או סוגריים
    segments = re.split(r"[-_()\s]+", stem)
    candidates: list[str] = []
    for seg in segments:
        for m in _PN_PATTERN.findall(seg):
            # דרישות:
            # 1. אורך סביר (5-15)
            # 2. גם אות וגם ספרה
            # 3. לא ברשימה השחורה
            if not (5 <= len(m) <= 15):
                continue
            if m.isdigit() or not any(c.isalpha() for c in m):
                continue
            if any(bl in m for bl in _PN_BLACKLIST):
                continue
            candidates.append(m)
    if not candidates:
        return ""
    # עדיפות ל-prefix מוכר
    for c in candidates:
        if c.startswith(_KNOWN_PN_PREFIXES):
            return c
    # אחרת — הארוך ביותר, אבל רק אם 6+ תווים (להיות זהירים)
    longest = max(candidates, key=len)
    return longest if len(longest) >= 6 else ""


def _reconcile_part_number(stage1: dict, filename: str) -> None:
    """משלים part_number כש-Stage 1 לא הצליח לחלץ.

    כללים (שמרני — לא מחליפים ערך תקף קיים):
    - אם part_number ריק אבל drawing_number קיים → השתמש ב-drawing_number
      (נפוץ ברפאל — אותו ערך מופיע ב-P.N. וב-DRAWING NO.).
    - אחרת, אם שם הקובץ מכיל מועמד סביר — השתמש בו.
    """
    pn = (stage1.get("part_number") or "").strip()
    if pn:
        return  # יש כבר ערך — לא נוגעים

    dn = (stage1.get("drawing_number") or "").strip()
    if dn:
        stage1["part_number"] = dn
        logger.info(f"📝 part_number הושלם מ-drawing_number: {dn}")
        return

    fname_pn = _extract_pn_from_filename(filename)
    if fname_pn:
        stage1["part_number"] = fname_pn
        logger.info(f"📝 part_number הושלם משם הקובץ: {fname_pn}")


def _proc_to_str(p) -> str:
    """ממיר תהליך (str או dict) למחרוזת אחת לתצוגה / סיכום."""
    if isinstance(p, dict):
        type_he = (p.get("type_he") or "").strip()
        type_en = (p.get("type") or "").strip()
        head = type_he or type_en or (p.get("name") or "").strip()
        thickness = (p.get("thickness") or "").strip()
        std = (p.get("standard") or "").strip()
        rohs = " (RoHS)" if p.get("rohs") is True else ""
        parts = [x for x in [head, thickness, std] if x]
        return " — ".join(parts) + rohs
    return str(p or "").strip()


def extract_drawing(pdf_path: str | Path, use_ocr_fallback: bool = True) -> dict:
    """
    חילוץ מלא של שרטוט PDF עם cost tracking ו-OCR fallback.

    Args:
        pdf_path: נתיב לקובץ PDF
        use_ocr_fallback: האם להפעיל OCR fallback אם Stage 1 חלש

    Returns:
        dict עם כל השדות + _cost_info עם פירוט עלויות
    """
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(f"קובץ לא נמצא: {pdf_path}")

    logger.info(f"מעבד שרטוט: {pdf_path.name}")

    images = pdf_to_images(pdf_path, dpi=300)
    logger.info(f"PDF הומר ל-{len(images)} עמודים")

    client = get_client()
    deployment = get_deployment()
    tracker = DrawingCostTracker(pdf_path.name)

    # ─── OCR מוקדם (פעם אחת) — עוזר עם NOTES בעברית RTL וקריאת ספרות ───
    ocr_text = ""
    ocr_used = False
    if is_ocr_available():
        try:
            ocr_text = extract_text_from_pdf(pdf_path)
            ocr_used = bool(ocr_text.strip())
        except Exception as exc:
            logger.warning("OCR נכשל: %s", exc)

    # ─── Stage 1 — מידע בסיסי ───
    logger.info("Stage 1: חילוץ מידע בסיסי...")
    stage1_prompt = (
        build_enhanced_prompt(STAGE_1_PROMPT, ocr_text) if ocr_text else STAGE_1_PROMPT
    )
    stage1, usage1 = _safe_call(_call_vision, client, deployment, stage1_prompt, images)
    tracker.add_stage("stage_1_basic_info", calculate_cost(usage1, deployment))

    # Fallback נוסף רק אם Stage 1 עדיין חלש (OCR כבר הוזרק — ננסה שוב עם דגש)
    if use_ocr_fallback and should_use_fallback(stage1) and ocr_text:
        logger.info("⚠️ Stage 1 חלש גם עם OCR — מנסה שוב עם prompt מודגש...")
        try:
            stage1_retry, usage_retry = _safe_call(
                _call_vision, client, deployment, stage1_prompt, images
            )
            tracker.add_stage(
                "stage_1_ocr_retry", calculate_cost(usage_retry, deployment)
            )
            for key, value in stage1_retry.items():
                if value and not stage1.get(key):
                    stage1[key] = value
        except Exception as e:
            logger.warning(f"Stage 1 retry נכשל: {e}")

    # ─── Stage 2 — תהליכים ───
    logger.info("Stage 2: חילוץ תהליכים...")
    stage2_prompt = (
        build_enhanced_prompt(STAGE_2_PROMPT, ocr_text) if ocr_text else STAGE_2_PROMPT
    )
    stage2, usage2 = _safe_call(_call_vision, client, deployment, stage2_prompt, images)
    tracker.add_stage("stage_2_processes", calculate_cost(usage2, deployment))

    # ─── Retry חכם לציפוי: אם ציפוי ריק אבל הטקסט מזכיר ציפוי — נסה שוב ───
    coatings_empty = not (stage2.get("coating_processes") or stage2.get("painting_processes"))
    if coatings_empty:
        hint_text = " ".join([
            str(stage1.get("notes") or ""),
            str(stage2.get("notes") or ""),
            ocr_text,
        ])
        if _COATING_KEYWORDS_RE.search(hint_text):
            logger.warning(
                "Stage 2 החזיר ציפוי ריק אך הטקסט מזכיר ציפוי — מבצע retry..."
            )
            retry_prompt = (
                stage2_prompt
                + "\n\n⚠️ שים לב! בשרטוט מופיעות מילות מפתח של ציפוי/תקן "
                "(למשל CONVERSION COATING, MIL-DTL-5541, ANODIZE, "
                "ELECTROLESS NICKEL, ASTM B633 וכו'). חובה לחלץ את כל "
                "הציפויים המוזכרים בשרטוט למערך coating_processes או "
                "painting_processes, עם פרטי התקן המלאים (TYPE/CLASS/GRADE)."
            )
            try:
                stage2_retry, usage_retry = _safe_call(
                    _call_vision, client, deployment, retry_prompt, images
                )
                tracker.add_stage(
                    "stage_2_retry", calculate_cost(usage_retry, deployment)
                )
                for key, value in (stage2_retry or {}).items():
                    if value and not stage2.get(key):
                        stage2[key] = value
                if stage2.get("coating_processes") or stage2.get("painting_processes"):
                    logger.info("✅ Retry הצליח: נמצאו תהליכים")
                else:
                    logger.warning("⚠️ Retry לא מצא תהליכים גם עם OCR")
            except Exception as exc:
                logger.warning("Stage 2 retry נכשל: %s", exc)

    # ─── Post-processing: חילוץ material מתוך NOTES אם חסר ───
    if not (stage1.get("material") or "").strip():
        material_from_notes = _extract_material_from_notes(stage2.get("notes", ""))
        if material_from_notes:
            stage1["material"] = material_from_notes
            logger.info(f"📝 חומר חולץ מ-NOTES: {material_from_notes}")

    # ─── Post-processing: השלמה / תיקון part_number ───
    _reconcile_part_number(stage1, pdf_path.name)

    # ─── Stage 3 — סיכום עברי ───
    logger.info("Stage 3: יצירת סיכום עברי...")
    coatings_str = ", ".join(_proc_to_str(c) for c in stage2.get("coating_processes", []) if _proc_to_str(c))
    paintings_str = ", ".join(_proc_to_str(p) for p in stage2.get("painting_processes", []) if _proc_to_str(p))
    stage3_prompt = STAGE_3_PROMPT_TEMPLATE.format(
        material=stage1.get("material", ""),
        coatings=coatings_str,
        paintings=paintings_str,
    )
    hebrew_summary, usage3 = _safe_call(_call_text, client, deployment, stage3_prompt)
    tracker.add_stage("stage_3_hebrew_summary", calculate_cost(usage3, deployment))

    # ─── איחוד תוצאות ───
    result = {
        **stage1,
        **stage2,
        "process_summary_hebrew": hebrew_summary,
        "source_filename": pdf_path.name,
        "_cost_info": tracker.summary(),
        "_ocr_used": ocr_used,
    }

    # ─── התאמת מאסטרים ───
    try:
        result["master_matches"] = match_all_coatings(
            stage2.get("coating_processes", []),
            stage2.get("painting_processes", []),
            top_n=3,
        )
    except Exception as exc:  # pragma: no cover
        logger.warning("Master matching failed: %s", exc)
        result["master_matches"] = []

    tracker.save_to_log()

    logger.info(
        f"✅ חילוץ הושלם | עלות: ${tracker.total_cost():.4f} "
        f"(~₪{tracker.total_cost() * 3.7:.3f})"
    )
    return result
