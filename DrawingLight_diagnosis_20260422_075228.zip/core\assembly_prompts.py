"""
Prompts ייעודיים למצב 'מכלולים מרובים' (Assembly Mode).

חשוב: קובץ זה נפרד לחלוטין מ-core/prompts.py כדי שהמצב החדש
לא ישפיע על המצב הקיים של ניתוח שרטוט בודד.

המצב הזה מחלץ את **כל** תכולת השרטוט (כולל עיבוד שבבי), ללא התאמת מאסטרים,
ובסוף מנתח את הקשרים בין כל השרטוטים שהועלו (אבא/בן/כמויות).
"""

# ───────────────────────────────────────────────────────────────
# Stage 1 — מידע בסיסי (זהה ברוחו ל-STAGE_1_PROMPT הקיים, אבל עצמאי)
# ───────────────────────────────────────────────────────────────
ASSEMBLY_STAGE_1_PROMPT = """אתה מומחה לזיהוי מידע משרטוטים הנדסיים (מצב מכלולים).

⚙️ כללי זהב:
- חלץ רק מידע שמופיע במפורש בטקסט/תמונה.
- העתק ערכים בדיוק כפי שכתובים.
- אם שדה לא קיים — החזר מחרוזת ריקה "".
- אל תמציא ואל תנחש!

חלץ מ-TITLE BLOCK:

1. part_number — מספר פריט / P/N / PART NO. / CATALOG NO. / מק"ט.
   ⚠️ DATE / CAGE CODE / SIZE / ASSEMBLY NUMBER ≠ part_number.
2. revision — גרסה / REV.
3. drawing_number — מספר שרטוט / DWG NO / Drawing No.
4. customer — שם לקוח / Customer / לוגו של חברה.
5. material — חומר גלם (העתק מדויק, למשל "ALUMINUM ALLOY 6061-T651 PLATE L=144. W=48. T=0.313 INCH").
6. quantity — כמות יחידות בשרטוט (אם מצוין QTY/QUANTITY/כמות, למשל מתוך BOM או טבלת חומרים).
   אם לא מצוין → "".
7. assembly_role — אם השרטוט הוא של מכלול אב או חלק בודד:
   - "ASSEMBLY" אם רואים שם DETAIL LIST / BOM / PARTS LIST / ASSEMBLY DRAWING.
   - "PART" אם זה שרטוט חלק בודד ללא טבלת חלקים.
   - "" אם לא ברור.
8. bom_items — אם השרטוט הוא של מכלול ויש טבלת חלקים, חלץ אותם:
   מערך אובייקטים: {"item_no": "", "part_number": "", "description": "", "qty": ""}
   אם אין טבלה → [].

🔵 RAFAEL — אם רואים את הלוגו / השם "RAFAEL":
   • CAT NO. ≠ part_number.
   • P.N. הוא ה-part_number (PWRL30512A, FTLS02016A, MMA574602C וכו').
   • DRAWING NO. הוא drawing_number (8H-A33448, 22H-013288 וכו').
   • REV הוא אות (A, B, C, D, G).
   • customer = "RAFAEL".

⚠️ קריאה תו-אחר-תו (טעויות שכיחות בספרות קטנות):
   • "B" ≠ "8",  "1" ≠ "I",  "0" ≠ "O",  "6" ≠ "8",  "5" ≠ "S",  "2" ≠ "Z".
   • 🔍 ספור את הספרות פעמיים! מספרי P.N. של רפאל **באורך קבוע**:
     BP70689A (7 תווים) ≠ BP7069A (6 תווים). אם אתה לא בטוח — קרא שוב, אל תקצר!
   • ברוב שרטוטי החלק הבודד ברפאל P.N. = DRAWING NO. — אם הם נראים שונים
     בספרה אחת, סביר שטעית באחד מהם.

החזר JSON בלבד:
{
  "part_number": "",
  "revision": "",
  "drawing_number": "",
  "customer": "",
  "material": "",
  "quantity": "",
  "assembly_role": "",
  "bom_items": []
}
"""


# ───────────────────────────────────────────────────────────────
# Stage 2 — תכולה מלאה: עיבוד שבבי, גימורים, תקנים, אריזה, הערות
# ───────────────────────────────────────────────────────────────
ASSEMBLY_STAGE_2_PROMPT = """אתה מומחה לחילוץ **כל תכולת** שרטוט הנדסי לטובת תכנון ייצור של מכלול.

⚙️ כללי Evidence קשיחים:
- חלץ רק מה שמופיע במפורש בשרטוט (PRODUCTION ROUTING CHART, NOTES, Title Block, BOM).
- אסור לנחש או להשלים.
- העתק ערכים בדיוק כפי שכתובים, כולל קודי תקן וגוונים.
- אם NOTES בעברית RTL — קרא תו-אחר-תו.

🎯 מצב 'מכלולים': נדרש לחלץ **את כל הסעיפים מטבלת ה-PRODUCTION ROUTING CHART**
   (10 MATERIAL, 20 MACHINING, 30 SURFACE TREATMENT, 40 PAINTING, 50 INSPECTION,
   60 FINAL APPROVAL, 70 PACKING וכו') — לפי הסדר שמופיעים.

חלץ את השדות הבאים:

1. machining_processes — תהליכי עיבוד שבבי / יצור מכני (מערך, לפי סדר):
   כל פריט:
   {
     "step_no": "<מספר השלב כמו 20.1, 20.3.1>",
     "name_en": "<שם באנגלית בדיוק כמו בשרטוט>",
     "name_he": "<תרגום לעברית>",
     "details": "<פרטים נוספים: מידות, סובלנויות, הערות>"
   }
   כולל למשל:
   - Engraving / חריטה (גובה תו, פונט, צבע)
   - Drilling / קידוח
   - Milling / כרסום
   - Turning / חריטה
   - Grinding / השחזה
   - Threading / הברגה
   - Deburring / הסרת גרדים
   - "ALL DIMENSIONS AFTER SURFACE TREATMENT" וכד'.
   ⚠️ אל תכלול כאן ציפויים/צביעה/אריזה/בדיקה — להם יש שדות נפרדים.

2. coating_processes — תהליכי ציפוי / פלטינג / טיפול שטח (מערך):
   כל פריט:
   {
     "step_no": "<מספר השלב, למשל 30.1>",
     "type": "<קטגוריה באנגלית קצרה>",
     "type_he": "<אותה קטגוריה בעברית>",
     "name": "<תיאור מלא כפי שכתוב>",
     "thickness": "",
     "standard": "<תקן מלא כולל CLASS / TYPE / GRADE>",
     "rohs": true/false
   }
   קטגוריות אפשריות (type / type_he): "Conversion / המרה כימית", "Anodize / אנודייז",
   "Hard Anodize / אנודייז קשה", "Passivation / פסיבציה",
   "Electroless Nickel / ניקל אלקטרולס", "Nickel / ניקל", "Zinc / אבץ",
   "Cadmium / קדמיום", "Chrome / כרום", "Hard Chrome / כרום קשה",
   "Tin / בדיל", "Silver / כסף", "Gold / זהב", "Copper / נחושת",
   "Black Oxide / תחמוצת שחורה", "Phosphate / פוספט",
   "Dry Film Lubricant / שימון יבש".
   ⚠️ rohs=true רק אם מופיע במפורש "RoHS" ליד התהליך.

3. painting_processes — תהליכי צביעה (מערך):
   כל פריט:
   {
     "step_no": "<למשל 40.1>",
     "type": "",
     "type_he": "",
     "name": "<שם מלא + צבע / RAL / FED-STD>",
     "thickness": "",
     "standard": "",
     "rohs": false
   }

4. inspection_processes — תהליכי בדיקה (מערך):
   {
     "step_no": "<למשל 50.1>",
     "name_en": "",
     "name_he": "",
     "details": ""
   }
   כולל: Visual Inspection, Sampling Inspection, Inspection Report, Dimensional וכו'.

5. final_approval — תהליכי אישור סופי (מערך):
   {"step_no": "", "name_en": "", "name_he": "", "details": ""}
   כולל: Verification of Documents, Serviceability Tag.

6. additional_processes — תהליכים מלווים שלא נכנסים למעלה:
   {"name_en": "", "name_he": ""}
   כולל: Heat Treatment, Sand Blasting, Masking, Demasking, Marking, Tag & Bag,
   Hydrogen Degassing, Insert Installation וכו'.

7. packaging_notes — אריזה (אובייקט):
   {"step_no": "", "en": "", "he": ""}

8. standards — רשימה שטוחה של כל התקנים שמופיעים בשרטוט (מערך מחרוזות, ללא כפילויות):
   "MIL-A-8625 Type II Class 1", "AMS-C-26074D Class 4 Grade A", "ISO 3098/1",
   "FED-STD-595", "ASTM B545-13 Class C+", וכו'.

9. notes — הערות כלליות (מחרוזת אחת).

החזר JSON בלבד:
{
  "machining_processes": [],
  "coating_processes": [],
  "painting_processes": [],
  "inspection_processes": [],
  "final_approval": [],
  "additional_processes": [],
  "packaging_notes": {"step_no": "", "en": "", "he": ""},
  "standards": [],
  "notes": ""
}
"""


# ───────────────────────────────────────────────────────────────
# Stage 3 (Assembly) — ניתוח קשרי אבא/בן/כמויות בין השרטוטים
# ───────────────────────────────────────────────────────────────
ASSEMBLY_RELATIONSHIPS_PROMPT_TEMPLATE = """אתה מהנדס ייצור בכיר. לפניך רשימת שרטוטים שנותחו —
חלקם מכלולי-אב (ASSEMBLY) וחלקם חלקים בודדים (PART).

המשימה: לזהות את הקשרים ההיררכיים בין השרטוטים — מי מכיל את מי, ובאיזו כמות.

📋 נתוני השרטוטים:
{drawings_data}

📐 מה לעשות:
1. לזהות איזה שרטוט הוא מכלול-אב (ASSEMBLY) ואילו הם חלקיו (PART).
2. אם מכלול-אב מציג BOM/Parts List — להתאים כל פריט בטבלה ל-part_number של אחד השרטוטים האחרים שהועלו.
3. לציין את הכמות של כל חלק במכלול (אם הופיעה).
4. לציין את החומר של כל חלק.
5. לזהות שרטוטים שלא נמצא להם הורה — אם הם נראים כעצמאיים או חסרים מהרשימה.

📤 פלט — JSON אחד בלבד:
{{
  "summary_he": "<פסקה קצרה בעברית המסבירה את המבנה הכולל של המכלול>",
  "assemblies": [
    {{
      "parent_part_number": "",
      "parent_drawing_number": "",
      "children": [
        {{
          "part_number": "",
          "drawing_number": "",
          "description": "",
          "qty": "",
          "found_in_uploaded_files": true
        }}
      ]
    }}
  ],
  "orphans": [
    {{"part_number": "", "drawing_number": "", "reason_he": ""}}
  ],
  "missing_children": [
    {{"part_number": "", "description": "", "qty": "", "needed_by_he": ""}}
  ],
  "warnings_he": []
}}

⚠️ כללים:
- אל תמציא part_numbers שלא הופיעו בנתונים.
- אם BOM קיים אבל לא הועלה השרטוט של החלק → רשום ב-missing_children.
- אם שרטוט הוא PART אבל לא נמצא לו הורה → orphans.
- אם אחד הפריטים הוא **תרשים מכלול / Exploded View** (assembly_role מכיל
  "Overview Image"): השתמש בו כמפת-מבנה ראשית — בועיות (Find Numbers)
  בתרשים מציינות אילו חלקים מרכיבים את המכלול, גם אם ה-PN המדויק לא נראה
  בתמונה. חבר אותם לחלקים שכן הועלו לפי item_no/qty.
- חשוב: השב JSON בלבד, ללא טקסט נוסף.
"""


# ───────────────────────────────────────────────────────────────
# Overview Image — ניתוח תמונת תרשים מכלול (Exploded View / BOM render)
# ───────────────────────────────────────────────────────────────
ASSEMBLY_OVERVIEW_IMAGE_PROMPT = """אתה מהנדס ייצור. קיבלת **תמונה של תרשים מכלול** (Exploded View / Assembly Overview).
זו אינה שרטוט הנדסי מלא עם title block — אלא תצוגה גרפית של המכלול עם בועיות מספור (Find Numbers / Item Numbers).

📐 המשימה:
1. ספור את כל הבועיות הממוספרות שמופיעות בתמונה (1, 2, 3, ...).
2. עבור כל בועיה — תאר בקצרה מה הפריט נראה (למשל: "מסילה אופקית", "גלגל", "מסגרת").
3. אם רואים כמויות (qty) או טקסט נלווה — רשום אותם.
4. אם יש כותרת/שם למכלול — חלץ אותה ל-part_number / drawing_number.

⚠️ חשוב מאוד:
- אל תמציא PN/standards שלא רואים בתמונה. תרשים-מכלול לרוב אינו מכיל PN של החלקים — רק מספרי בועיה.
- השאר שדות שלא רלוונטיים (material, machining_processes, coating_processes וכו') כריקים/ריקות.
- assembly_role חייב להיות בדיוק: "Assembly Overview Image".

📤 פלט — JSON אחד בלבד:
{
  "part_number": "",
  "drawing_number": "",
  "revision": "",
  "customer": "",
  "material": "",
  "quantity": "",
  "assembly_role": "Assembly Overview Image",
  "bom_items": [
    {"item_no": "1", "part_number": "", "qty": "", "description": "<תיאור קצר של מה שנראה בבועיה>"},
    {"item_no": "2", "part_number": "", "qty": "", "description": "..."}
  ],
  "machining_processes": [],
  "coating_processes": [],
  "painting_processes": [],
  "inspection_processes": [],
  "final_approval": "",
  "additional_processes": [],
  "packaging_notes": "",
  "standards": [],
  "notes": "<הערה כללית קצרה על המבנה הנראה — למשל 'מכלול מסילות גלגלים על שלדה ניידת'>"
}
"""
