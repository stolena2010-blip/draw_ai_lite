# 📝 CHANGELOG — DrawingAI Lite

> כל השינויים המהותיים בפרויקט. הפורמט מבוסס על
> [Keep a Changelog](https://keepachangelog.com/he/), הגרסאות לפי
> [Semantic Versioning](https://semver.org/lang/he/).

---

## [Unreleased] — 22/04/2026

### ✨ Added
- **דוח עץ מוצר מקוצר (PDF)** — `storage/pdf_report.py::build_tree_pdf()`
  כולל טבלת עץ (רמה · P/N · Drawing · תיאור · כמות · חומר) וסכמה ויזואלית מקננת.
- **ייצוא עץ מוצר ל-Excel** — `storage/pdf_report.py::build_tree_excel()`
  גיליון יחיד `Tree` ב-RTL, עם סימון "הועלה?" לחלקים שנמצאו בקבצי הקלט.
- **תמיכה בתמונת Exploded View** במצב מכלולים —
  `core/pdf_utils.py::image_file_to_b64()` ו-
  `core/assembly.py::extract_assembly_overview_image()`. מקבל PNG/JPG/JPEG/WEBP.
- **`ASSEMBLY_OVERVIEW_IMAGE_PROMPT`** — פרומפט ייעודי לניתוח Exploded View
  (סופר Find Numbers / בועות, מתאר חלקים בלי לנחש PN).
- **מיון אוטומטי**: תמונת מכלול (Overview Image) ממוינת תמיד לראש רשימת
  השרטוטים, ללא קשר לסדר ההעלאה.
- **`tests/test_master_matcher.py`** — 26 בדיקות יחידה ל-Master Matcher.
- **`AZURE_SURCHARGE`** ב-`.env` — תוסף Azure ניתן להגדרה (1.10 / 1.20 וכד').
- **`.env.example`** — תבנית הגדרות מלאה.
- **אזהרת חוסר Masters.xlsx** ב-`app.py`.

### 🐛 Fixed
- **`StreamlitAPIException` בניווט בין שרטוטים** — `ui_assembly.py::_goto()`
  לא מנסה יותר לכתוב ל-`asm_jump` אחרי יצירת ה-widget.
- **רגקס PN רחב מדי** — נוסף whitelist של prefixes מוכרים
  (PWRL, BBLE, HLTA, FTL, BG, IAI, EL וכו') ו-blacklist (CAGE, NOTES, DWG…).
- **טבלאות נחתכות באמצע ב-PDF** — נוספו `<thead>` עם
  `display: table-header-group`, `tr { page-break-inside: avoid }`,
  `table-layout: fixed` + `<colgroup>` עם מחלקות רוחב קבועות.
- **התהפכויות עברית/אנגלית ב-PDF** — מעטפת `_ltr()` עם `<bdi dir="ltr">`
  לכל ערך לועזי (PN, Drawing, תקנים, עוביים, כמויות, step_no, name_en).

### 🧪 Tests
```powershell
.\.venv\Scripts\Activate.ps1
pytest tests/ -v
# 26 passed
```

---

## עדכונים קודמים

### Assembly Mode (גרסת הבסיס)
- ניתוח מספר שרטוטים יחד עם BOM, עיבוד שבבי, ציפויים, צביעות, בדיקות
- ניתוח קשרי אבא/בן (`analyze_relationships`)
- דוח PDF מסכם מלא (RTL עברית) דרך PyMuPDF Story API
- ניווט עם חצים בין השרטוטים

### Single Mode (גרסת הבסיס)
- Pipeline 3 שלבים (basic → processes → Hebrew summary)
- OCR fallback (Tesseract) להעצמת prompt
- Master Matcher: Top-3 מתוך 1239 מאסטרים, אלגוריתם 9 קריטריונים משוקללים
- שמירה ל-JSON / Excel
- מעקב עלויות ב-`output/costs.jsonl`

### Dual Model Support
- `gpt-4o-vision` (Vision) ו-`gpt-5.4` (Reasoning)
- מתג `ACTIVE_MODEL` ב-`.env`; `is_reasoning_model()` מתאים kwargs אוטומטית
  (`max_completion_tokens` במקום `max_tokens`, ללא `temperature`)

---

## פתוח לתיקון בעתיד

ראה [DRAWINGAI_LITE_CODE_REVIEW_FINDINGS.md](DRAWINGAI_LITE_CODE_REVIEW_FINDINGS.md):

- 🟠 תיקון 5: חילוץ `core/ai_helpers.py` משותף ל-`extractor.py` ו-`assembly.py`
- 🟠 תיקון 6: Drawing Cache (MD5 hash → חיסכון בעלויות על קבצים חוזרים)
- 🟠 תיקון 7: Error Boundary (`core/exceptions.py` + try/except מובנה)
- 🟡 שיפור 8: `save_to_excel` רב-גיליונות (Coatings / Master_Matches / Standards)
- 🐛 באג 12: `coatings_empty` retry — prompt מפורש במקום אותו prompt + הערה
- 🔴 תיקון 2: OCR fallback אמיתי (לא always-on)
- 🔴 תיקון 3: `_reconcile_part_number` זהיר יותר (לא להחליף DN ב-PN)
