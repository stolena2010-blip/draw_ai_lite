"""
יצירת דוח PDF למצב 'מכלולים מרובים'.

משתמש ב-PyMuPDF (fitz) ובפונקציה insert_htmlbox התומכת ב-HTML/CSS
ובכיווניות RTL — מאפשרת רינדור עברית באופן אמין.

הדוח כולל:
  • שער עם תאריך + מספר שרטוטים
  • סיכום עברי של ניתוח הקשרים
  • טבלת מכלולים (אבא/בן/כמויות) + יתומים + חלקים חסרים
  • כרטיס מפורט לכל שרטוט: מזהים, BOM, עיבוד שבבי, ציפויים, צביעות,
    בדיקות, אישורים, אריזה, תקנים, הערות.
"""
from __future__ import annotations

import html
from datetime import datetime
from pathlib import Path

import fitz  # PyMuPDF


# ─── עזרים ───
def _h(s) -> str:
    """Escape בטוח ל-HTML."""
    return html.escape(str(s if s is not None else ""), quote=True)


def _ltr(s) -> str:
    """עוטף ערך אנגלי/מספרי ב-bdi כדי שיוצג LTR בתוך פסקה RTL.

    מונע 'התהפכויות' של PN/Drawing No./תקנים/כמויות בתוך עברית.
    """
    if s is None or s == "":
        return ""
    return f'<bdi dir="ltr">{_h(s)}</bdi>'


def _join_chip(items: list[str]) -> str:
    if not items:
        return "—"
    return " · ".join(items)


# ─── רכיבי HTML ───
_BASE_CSS = """
<style>
  * { font-family: 'Arial', 'Segoe UI', sans-serif; }
  body { color: #212529; }
  h1 { color: #0d6efd; font-size: 22pt; margin: 0 0 8pt 0; }
  h2 { color: #0d6efd; font-size: 14pt; margin: 10pt 0 4pt 0;
       border-bottom: 1px solid #cfe2ff; padding-bottom: 2pt;
       page-break-after: avoid; }
  h3 { color: #495057; font-size: 11pt; margin: 8pt 0 2pt 0;
       page-break-after: avoid; }
  p, div, td, th { font-size: 9.5pt; line-height: 1.5; }
  table { border-collapse: collapse; width: 100%; margin: 4pt 0 8pt 0;
          table-layout: fixed; }
  thead { display: table-header-group; }   /* חזרה אוטומטית של כותרות */
  tr    { page-break-inside: avoid; }      /* לא לחתוך שורה באמצע */
  th { background: #e9ecef; color: #212529; padding: 4pt 6pt;
       border: 1px solid #adb5bd; text-align: right; font-size: 9pt;
       word-wrap: break-word; }
  td { padding: 3pt 6pt; border: 1px solid #ced4da; font-size: 9pt;
       vertical-align: top; word-wrap: break-word; overflow-wrap: anywhere; }
  .meta-card { background: #eef5ff; border: 1pt solid #0d6efd;
               border-radius: 6pt; padding: 8pt 10pt; margin: 4pt 0 8pt 0;
               page-break-inside: avoid; }
  .summary { background: #d4edda; color: #155724; padding: 8pt 10pt;
             border-radius: 5pt; margin: 4pt 0 8pt 0; line-height: 1.7;
             page-break-inside: avoid; }
  .pkg-he { background: #fff3cd; color: #664d03; padding: 6pt 9pt;
            border-radius: 5pt; margin: 3pt 0;
            page-break-inside: avoid; }
  .notes { background: #f8f9fa; border-right: 3pt solid #6c757d;
           padding: 6pt 10pt; margin: 4pt 0; white-space: pre-wrap;
           page-break-inside: avoid; }
  code { font-family: Consolas, monospace; background: #f1f3f5;
         padding: 1pt 4pt; border-radius: 3pt; font-size: 8.5pt;
         direction: ltr; unicode-bidi: bidi-override; }
  bdi  { unicode-bidi: isolate; }
  .muted { color: #6c757d; }
  .badge-ok { background: #198754; color: white; padding: 1pt 5pt;
              border-radius: 3pt; font-size: 8pt; }
  .badge-no { background: #dc3545; color: white; padding: 1pt 5pt;
              border-radius: 3pt; font-size: 8pt; }
  .stds code { display: inline-block; margin: 1pt 2pt; }
  /* רוחבי עמודות קבועים לטבלאות עיקריות */
  table.tbl-bom    col.c-item   { width: 10%; }
  table.tbl-bom    col.c-pn     { width: 22%; }
  table.tbl-bom    col.c-desc   { width: 53%; }
  table.tbl-bom    col.c-qty    { width: 15%; }
  table.tbl-coat   col.c-step   { width: 7%; }
  table.tbl-coat   col.c-typeh  { width: 14%; }
  table.tbl-coat   col.c-typee  { width: 12%; }
  table.tbl-coat   col.c-name   { width: 24%; }
  table.tbl-coat   col.c-std    { width: 19%; }
  table.tbl-coat   col.c-thick  { width: 16%; }
  table.tbl-coat   col.c-rohs   { width: 8%; }
  table.tbl-step   col.c-step   { width: 8%; }
  table.tbl-step   col.c-en     { width: 22%; }
  table.tbl-step   col.c-he     { width: 22%; }
  table.tbl-step   col.c-det    { width: 48%; }
  table.tbl-rel    col.c-pn     { width: 20%; }
  table.tbl-rel    col.c-dwg    { width: 20%; }
  table.tbl-rel    col.c-desc   { width: 38%; }
  table.tbl-rel    col.c-qty    { width: 12%; }
  table.tbl-rel    col.c-flag   { width: 10%; }
</style>
"""


def _wrap_rtl(inner_html: str) -> str:
    """עוטף תוכן ב-HTML מלא עם CSS, כיוון RTL ועברית."""
    return (
        '<html dir="rtl" lang="he"><head><meta charset="utf-8">'
        + _BASE_CSS
        + '</head><body dir="rtl" style="text-align:right; '
        + 'unicode-bidi:plaintext;">'
        + inner_html
        + "</body></html>"
    )


# ─── בלוקי תוכן ───
def _cover_html(n_drawings: int) -> str:
    ts = datetime.now().strftime("%d/%m/%Y %H:%M")
    return (
        f"<h1>📐 דוח ניתוח מכלול</h1>"
        f'<div class="meta-card">'
        f'<p><span class="muted">📅 תאריך הפקה:</span> <b>{ts}</b></p>'
        f'<p><span class="muted">📄 מספר שרטוטים בניתוח:</span> '
        f'<b>{n_drawings}</b></p>'
        f"</div>"
    )


def _relationships_html(rel: dict | None) -> str:
    if not rel:
        return ""
    parts = ["<h2>🔗 ניתוח קשרי המכלול</h2>"]

    summary = (rel.get("summary_he") or "").strip()
    if summary:
        parts.append(f'<div class="summary">📋 <b>סיכום:</b><br>{_h(summary)}</div>')

    asms = rel.get("assemblies") or []
    if asms:
        parts.append("<h3>🧩 מכלולים שזוהו</h3>")
        for a in asms:
            ppn = _ltr(a.get("parent_part_number") or "—")
            pdn = _ltr(a.get("parent_drawing_number") or "—")
            kids = a.get("children") or []
            parts.append(
                f'<p><b>📦 מכלול:</b> P/N={ppn} · '
                f'DWG={pdn} · {len(kids)} חלקים</p>'
            )
            if kids:
                head = (
                    "<thead><tr>"
                    "<th>P/N</th><th>Drawing</th><th>תיאור</th>"
                    "<th>כמות</th><th>הועלה?</th>"
                    "</tr></thead>"
                )
                rows = ""
                for k in kids:
                    if not isinstance(k, dict):
                        continue
                    in_files = k.get("found_in_uploaded_files")
                    badge = ('<span class="badge-ok">✓</span>' if in_files
                             else '<span class="badge-no">✗</span>')
                    rows += (
                        f"<tr>"
                        f"<td>{_ltr(k.get('part_number',''))}</td>"
                        f"<td>{_ltr(k.get('drawing_number',''))}</td>"
                        f"<td>{_h(k.get('description',''))}</td>"
                        f"<td>{_ltr(k.get('qty',''))}</td>"
                        f"<td>{badge}</td>"
                        f"</tr>"
                    )
                parts.append(
                    '<table class="tbl-rel">'
                    '<colgroup>'
                    '<col class="c-pn"><col class="c-dwg">'
                    '<col class="c-desc"><col class="c-qty">'
                    '<col class="c-flag">'
                    '</colgroup>'
                    f'{head}<tbody>{rows}</tbody></table>'
                )

    orphans = rel.get("orphans") or []
    if orphans:
        parts.append("<h3>🪙 שרטוטים ללא הורה</h3>")
        head = "<thead><tr><th>P/N</th><th>Drawing</th><th>סיבה</th></tr></thead>"
        rows = ""
        for o in orphans:
            if not isinstance(o, dict):
                continue
            rows += (
                f"<tr><td>{_ltr(o.get('part_number',''))}</td>"
                f"<td>{_ltr(o.get('drawing_number',''))}</td>"
                f"<td>{_h(o.get('reason_he',''))}</td></tr>"
            )
        parts.append(f"<table>{head}<tbody>{rows}</tbody></table>")

    missing = rel.get("missing_children") or []
    if missing:
        parts.append("<h3>⚠️ חלקים שמופיעים ב-BOM אך לא הועלו</h3>")
        head = (
            "<thead><tr><th>P/N</th><th>תיאור</th>"
            "<th>כמות</th><th>נדרש ע\"י</th></tr></thead>"
        )
        rows = ""
        for m in missing:
            if not isinstance(m, dict):
                continue
            rows += (
                f"<tr><td>{_ltr(m.get('part_number',''))}</td>"
                f"<td>{_h(m.get('description',''))}</td>"
                f"<td>{_ltr(m.get('qty',''))}</td>"
                f"<td>{_h(m.get('needed_by_he',''))}</td></tr>"
            )
        parts.append(f"<table>{head}<tbody>{rows}</tbody></table>")

    warnings = rel.get("warnings_he") or []
    if warnings:
        parts.append("<h3>💡 הערות / אזהרות</h3>")
        for w in warnings:
            parts.append(f'<div class="notes">⚠️ {_h(w)}</div>')

    return "".join(parts)


def _step_table(items: list, headers: list[tuple[str, str]],
                table_class: str = "tbl-step",
                col_classes: list[str] | None = None,
                ltr_keys: tuple[str, ...] = ()) -> str:
    """בונה טבלה כללית.
    headers     = [(label_he, key), ...]
    table_class = שם המחלקה ב-CSS (קובע רוחבי עמודות).
    col_classes = רשימת c-* מהמחלקות ב-CSS, באותו אורך כמו headers.
    ltr_keys    = keys שערכם לועזי וצריך להישאר LTR (PN, Drawing וכד').
    """
    if not items:
        return ""
    head = "".join(f"<th>{_h(label)}</th>" for label, _ in headers)
    rows = ""
    for it in items:
        if not isinstance(it, dict):
            it = {"name": str(it)}
        cells = ""
        for _, k in headers:
            val = it.get(k, "")
            cells += f"<td>{_ltr(val) if k in ltr_keys else _h(val)}</td>"
        rows += f"<tr>{cells}</tr>"

    colgroup = ""
    if col_classes and len(col_classes) == len(headers):
        cols = "".join(f'<col class="{c}">' for c in col_classes)
        colgroup = f"<colgroup>{cols}</colgroup>"

    return (
        f'<table class="{table_class}">{colgroup}'
        f'<thead><tr>{head}</tr></thead>'
        f'<tbody>{rows}</tbody></table>'
    )


def _drawing_html(d: dict, idx: int, total: int) -> str:
    pn = _ltr(d.get("part_number") or "—")
    dn = _ltr(d.get("drawing_number") or "—")
    rev = _ltr(d.get("revision") or "—")
    cust = _h(d.get("customer") or "—")
    mat = _h(d.get("material") or "—")
    qty = _ltr(d.get("quantity") or "—")
    role = _h(d.get("assembly_role") or "—")
    src = _ltr(d.get("source_filename") or "")

    parts = [
        f"<h2>📄 שרטוט {idx}/{total} — {pn}</h2>",
        '<div class="meta-card">',
        f'<p><span class="muted">קובץ:</span> {src}</p>',
        f'<p><span class="muted">פריט:</span> <b>{pn}</b> · '
        f'<span class="muted">שרטוט:</span> <b>{dn}</b> · '
        f'<span class="muted">גרסה:</span> <b>{rev}</b> · '
        f'<span class="muted">לקוח:</span> <b>{cust}</b></p>'
        f'<p><span class="muted">חומר:</span> <b>{mat}</b> · '
        f'<span class="muted">תפקיד:</span> <b>{role}</b> · '
        f'<span class="muted">כמות:</span> <b>{qty}</b></p>'
        "</div>",
    ]

    # BOM
    bom = d.get("bom_items") or []
    if bom:
        parts.append("<h3>📋 טבלת חלקים (BOM)</h3>")
        parts.append(_step_table(
            bom,
            [("Item", "item_no"), ("Part Number", "part_number"),
             ("תיאור", "description"), ("כמות", "qty")],
            table_class="tbl-bom",
            col_classes=["c-item", "c-pn", "c-desc", "c-qty"],
            ltr_keys=("item_no", "part_number", "qty"),
        ))

    # עיבוד שבבי
    machining = d.get("machining_processes") or []
    if machining:
        parts.append("<h3>🔧 עיבוד שבבי</h3>")
        parts.append(_step_table(
            machining,
            [("שלב", "step_no"), ("אנגלית", "name_en"),
             ("עברית", "name_he"), ("פרטים", "details")],
            table_class="tbl-step",
            col_classes=["c-step", "c-en", "c-he", "c-det"],
            ltr_keys=("step_no", "name_en"),
        ))

    # ציפויים
    coatings = d.get("coating_processes") or []
    if coatings:
        parts.append("<h3>🎨 ציפויים / טיפול שטח</h3>")
        head = (
            "<thead><tr><th>שלב</th><th>סוג (HE)</th><th>סוג (EN)</th>"
            "<th>תיאור</th><th>תקן</th><th>עובי</th><th>RoHS</th></tr></thead>"
        )
        rows = ""
        for c in coatings:
            if not isinstance(c, dict):
                continue
            rohs = '<span class="badge-ok">✓</span>' if c.get("rohs") else ""
            rows += (
                f"<tr>"
                f"<td>{_ltr(c.get('step_no',''))}</td>"
                f"<td>{_h(c.get('type_he',''))}</td>"
                f"<td>{_ltr(c.get('type',''))}</td>"
                f"<td>{_h(c.get('name',''))}</td>"
                f"<td>{_ltr(c.get('standard',''))}</td>"
                f"<td>{_ltr(c.get('thickness',''))}</td>"
                f"<td>{rohs}</td>"
                f"</tr>"
            )
        parts.append(
            '<table class="tbl-coat">'
            '<colgroup>'
            '<col class="c-step"><col class="c-typeh"><col class="c-typee">'
            '<col class="c-name"><col class="c-std"><col class="c-thick">'
            '<col class="c-rohs">'
            '</colgroup>'
            f"{head}<tbody>{rows}</tbody></table>"
        )

    # צביעות
    paintings = d.get("painting_processes") or []
    if paintings:
        parts.append("<h3>🖌️ צביעות</h3>")
        head = (
            "<thead><tr><th>שלב</th><th>סוג (HE)</th><th>סוג (EN)</th>"
            "<th>תיאור</th><th>תקן</th><th>עובי</th><th>RoHS</th></tr></thead>"
        )
        rows = ""
        for p in paintings:
            if not isinstance(p, dict):
                continue
            rohs = '<span class="badge-ok">✓</span>' if p.get("rohs") else ""
            rows += (
                f"<tr>"
                f"<td>{_ltr(p.get('step_no',''))}</td>"
                f"<td>{_h(p.get('type_he',''))}</td>"
                f"<td>{_ltr(p.get('type',''))}</td>"
                f"<td>{_h(p.get('name',''))}</td>"
                f"<td>{_ltr(p.get('standard',''))}</td>"
                f"<td>{_ltr(p.get('thickness',''))}</td>"
                f"<td>{rohs}</td>"
                f"</tr>"
            )
        parts.append(
            '<table class="tbl-coat">'
            '<colgroup>'
            '<col class="c-step"><col class="c-typeh"><col class="c-typee">'
            '<col class="c-name"><col class="c-std"><col class="c-thick">'
            '<col class="c-rohs">'
            '</colgroup>'
            f"{head}<tbody>{rows}</tbody></table>"
        )

    # בדיקות
    inspect = d.get("inspection_processes") or []
    if inspect:
        parts.append("<h3>🔍 בדיקות</h3>")
        parts.append(_step_table(
            inspect,
            [("שלב", "step_no"), ("אנגלית", "name_en"),
             ("עברית", "name_he"), ("פרטים", "details")],
            table_class="tbl-step",
            col_classes=["c-step", "c-en", "c-he", "c-det"],
            ltr_keys=("step_no", "name_en"),
        ))

    # אישור סופי
    final = d.get("final_approval") or []
    if final:
        parts.append("<h3>✅ אישור סופי</h3>")
        parts.append(_step_table(
            final,
            [("שלב", "step_no"), ("אנגלית", "name_en"),
             ("עברית", "name_he"), ("פרטים", "details")],
            table_class="tbl-step",
            col_classes=["c-step", "c-en", "c-he", "c-det"],
            ltr_keys=("step_no", "name_en"),
        ))

    # תהליכים מלווים
    additional = d.get("additional_processes") or []
    if additional:
        parts.append("<h3>🛠️ תהליכים מלווים</h3>")
        parts.append(_step_table(
            additional,
            [("אנגלית", "name_en"), ("עברית", "name_he")],
            table_class="tbl-step",
            col_classes=["c-en", "c-he"],
            ltr_keys=("name_en",),
        ))

    # תקנים
    stds = d.get("standards") or []
    if stds:
        parts.append("<h3>📜 כל התקנים שמופיעים בשרטוט</h3>")
        chips = " ".join(f"<code>{_h(s)}</code>" for s in stds)
        parts.append(f'<p class="stds">{chips}</p>')

    # אריזה
    pkg = d.get("packaging_notes") or {}
    if isinstance(pkg, dict) and (pkg.get("he") or pkg.get("en")):
        parts.append("<h3>📦 אריזה</h3>")
        if pkg.get("he"):
            parts.append(f'<div class="pkg-he">🇮🇱 {_h(pkg["he"])}</div>')
        if pkg.get("en"):
            parts.append(
                f'<div class="pkg-he" dir="ltr" style="text-align:left;">'
                f'🇬🇧 {_h(pkg["en"])}</div>'
            )

    # הערות
    notes = (d.get("notes") or "").strip()
    if notes:
        parts.append("<h3>📝 הערות השרטוט</h3>")
        parts.append(f'<div class="notes">{_h(notes)}</div>')

    return "".join(parts)


# ─── מנוע יצירת ה-PDF ───
def build_assembly_pdf(
    drawings: list[dict],
    relationships: dict | None,
    out_path: Path,
) -> Path:
    """בונה דוח PDF מלא ושומר אותו ל-out_path.

    משתמש ב-DocumentWriter + Story של PyMuPDF — מטפל אוטומטית
    בגלישת תוכן בין עמודים, כולל RTL לעברית.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    page_w, page_h = fitz.paper_size("a4")
    margin = 36
    mediabox = fitz.Rect(0, 0, page_w, page_h)
    where = fitz.Rect(margin, margin, page_w - margin, page_h - margin)

    # אוסף את כל ה-HTML לחלקים — כל חלק יתחיל בעמוד חדש
    sections: list[str] = []
    sections.append(_wrap_rtl(_cover_html(len(drawings)) + _relationships_html(relationships)))
    total = len(drawings)
    for i, d in enumerate(drawings, 1):
        sections.append(_wrap_rtl(_drawing_html(d, i, total)))

    writer = fitz.DocumentWriter(str(out_path))
    try:
        for html_content in sections:
            story = fitz.Story(html=html_content)
            more = 1
            while more:
                dev = writer.begin_page(mediabox)
                more, _filled = story.place(where)
                story.draw(dev)
                writer.end_page()
    finally:
        writer.close()

    return out_path


# ═══════════════════════════════════════════════════════════════
#  דוח עץ מוצר מקוצר — טבלה + סכמה
# ═══════════════════════════════════════════════════════════════

_TREE_CSS_EXTRA = """
<style>
  table.tbl-tree col.c-lvl   { width: 8%; }
  table.tbl-tree col.c-pn    { width: 20%; }
  table.tbl-tree col.c-dwg   { width: 16%; }
  table.tbl-tree col.c-desc  { width: 28%; }
  table.tbl-tree col.c-qty   { width: 8%; }
  table.tbl-tree col.c-mat   { width: 20%; }
  ul.tree { list-style: none; padding-right: 14pt; margin: 2pt 0; }
  ul.tree li { margin: 2pt 0; padding: 3pt 6pt;
               border-right: 2pt solid #0d6efd;
               background: #f8fbff; border-radius: 3pt;
               page-break-inside: avoid; }
  ul.tree li.lvl-0 { border-right-color: #0d6efd; background: #e7f1ff; }
  ul.tree li.lvl-1 { border-right-color: #6610f2; background: #f3ecff; }
  ul.tree li.lvl-2 { border-right-color: #20c997; background: #e7faf3; }
  ul.tree li.lvl-3 { border-right-color: #fd7e14; background: #fff1e6; }
  .tree-pn   { font-weight: bold; }
  .tree-meta { color: #495057; font-size: 9pt; }
  .tree-qty  { color: #198754; font-weight: bold; }
  .tree-mat  { color: #6c757d; font-style: italic; }
</style>
"""


def _wrap_rtl_tree(inner_html: str) -> str:
    return (
        '<html dir="rtl" lang="he"><head><meta charset="utf-8">'
        + _BASE_CSS + _TREE_CSS_EXTRA
        + '</head><body dir="rtl" style="text-align:right; '
        + 'unicode-bidi:plaintext;">'
        + inner_html + "</body></html>"
    )


def _build_drawing_index(drawings: list[dict]) -> dict:
    """ממפה PN → drawing dict לחיפוש מהיר של חומר/תיאור."""
    idx = {}
    for d in drawings or []:
        if not isinstance(d, dict):
            continue
        pn = (d.get("part_number") or "").strip().upper()
        if pn:
            idx[pn] = d
    return idx


def _resolve_material(node: dict, idx: dict) -> str:
    """מחזיר חומר מהשרטוט שהועלה לפי PN, או ריק."""
    pn = (node.get("part_number") or "").strip().upper()
    if pn and pn in idx:
        return (idx[pn].get("material") or "").strip()
    return ""


def _resolve_description(node: dict, idx: dict) -> str:
    """תיאור מהקשר אם קיים, אחרת מהשרטוט שהועלה."""
    desc = (node.get("description") or "").strip()
    if desc:
        return desc
    pn = (node.get("part_number") or "").strip().upper()
    if pn and pn in idx:
        d = idx[pn]
        return (d.get("description") or d.get("title")
                or d.get("name") or "").strip()
    return ""


def _flatten_tree_rows(
    drawings: list[dict],
    relationships: dict | None,
) -> list[dict]:
    """בונה רשימת שורות שטוחה עם רמה (level) לעץ המוצר.

    כל שורה: {level, part_number, drawing_number, description, qty, material}
    """
    idx = _build_drawing_index(drawings)
    rows: list[dict] = []
    seen_as_child: set[str] = set()

    asms = (relationships or {}).get("assemblies") or []
    if asms:
        for a in asms:
            if not isinstance(a, dict):
                continue
            ppn = (a.get("parent_part_number") or "").strip()
            pdn = (a.get("parent_drawing_number") or "").strip()
            parent_drawing = idx.get(ppn.upper(), {})
            rows.append({
                "level": 0,
                "part_number": ppn or "—",
                "drawing_number": pdn or parent_drawing.get("drawing_number", ""),
                "description": (parent_drawing.get("description")
                                or a.get("parent_description") or ""),
                "qty": "1",
                "material": parent_drawing.get("material", ""),
            })
            for k in (a.get("children") or []):
                if not isinstance(k, dict):
                    continue
                cpn = (k.get("part_number") or "").strip()
                if cpn:
                    seen_as_child.add(cpn.upper())
                rows.append({
                    "level": 1,
                    "part_number": cpn or "—",
                    "drawing_number": (k.get("drawing_number") or "").strip(),
                    "description": _resolve_description(k, idx),
                    "qty": (k.get("qty") or "").strip() or "1",
                    "material": _resolve_material(k, idx),
                })

    # שרטוטים שהועלו ולא הופיעו כילדים — נוסיף כשורות עצמאיות
    extras = []
    for d in drawings or []:
        if not isinstance(d, dict):
            continue
        pn = (d.get("part_number") or "").strip()
        if not pn or pn.upper() in seen_as_child:
            continue
        # אם כבר הוצג כהורה — דלג
        if any(r["level"] == 0 and r["part_number"].upper() == pn.upper()
               for r in rows):
            continue
        extras.append({
            "level": 0,
            "part_number": pn,
            "drawing_number": (d.get("drawing_number") or "").strip(),
            "description": (d.get("description") or "").strip(),
            "qty": (d.get("quantity") or "1").strip() or "1",
            "material": (d.get("material") or "").strip(),
        })

    if extras and not rows:
        # אין relationships בכלל — הצג רשימה שטוחה
        return extras
    rows.extend(extras)
    return rows


def _tree_table_html(rows: list[dict]) -> str:
    if not rows:
        return '<p class="muted">אין נתוני עץ להצגה.</p>'
    head = (
        "<thead><tr>"
        "<th>רמה</th><th>P/N</th><th>Drawing</th>"
        "<th>תיאור</th><th>כמות</th><th>חומר</th>"
        "</tr></thead>"
    )
    body = ""
    for r in rows:
        lvl = r.get("level", 0)
        indent = "·&nbsp;" * lvl
        body += (
            f"<tr>"
            f"<td>{lvl}</td>"
            f"<td>{indent}{_ltr(r.get('part_number',''))}</td>"
            f"<td>{_ltr(r.get('drawing_number',''))}</td>"
            f"<td>{_h(r.get('description',''))}</td>"
            f"<td>{_ltr(r.get('qty',''))}</td>"
            f"<td>{_h(r.get('material',''))}</td>"
            f"</tr>"
        )
    return (
        '<table class="tbl-tree">'
        '<colgroup>'
        '<col class="c-lvl"><col class="c-pn"><col class="c-dwg">'
        '<col class="c-desc"><col class="c-qty"><col class="c-mat">'
        '</colgroup>'
        f'{head}<tbody>{body}</tbody></table>'
    )


def _tree_schematic_html(rows: list[dict]) -> str:
    """סכמה מקננת — רשימה אינדנטית עם צבעים לפי רמה."""
    if not rows:
        return ""
    parts = ['<ul class="tree">']
    for r in rows:
        lvl = max(0, min(int(r.get("level", 0)), 3))
        pn = _ltr(r.get("part_number", "—"))
        dwg = r.get("drawing_number", "")
        desc = r.get("description", "")
        qty = r.get("qty", "")
        mat = r.get("material", "")

        meta_bits = []
        if dwg:
            meta_bits.append(f'DWG: {_ltr(dwg)}')
        if desc:
            meta_bits.append(_h(desc))
        meta_html = (' · '.join(meta_bits)) if meta_bits else ''

        tail_bits = []
        if qty:
            tail_bits.append(f'<span class="tree-qty">×{_ltr(qty)}</span>')
        if mat:
            tail_bits.append(f'<span class="tree-mat">[{_h(mat)}]</span>')
        tail_html = ' '.join(tail_bits)

        # אינדנט ויזואלי באמצעות margin-right (RTL)
        margin = lvl * 18
        parts.append(
            f'<li class="lvl-{lvl}" style="margin-right:{margin}pt;">'
            f'<span class="tree-pn">{pn}</span> '
            f'<span class="tree-meta">{meta_html}</span> '
            f'{tail_html}'
            f'</li>'
        )
    parts.append('</ul>')
    return ''.join(parts)


def _tree_cover_html(n_drawings: int, n_rows: int) -> str:
    ts = datetime.now().strftime("%d/%m/%Y %H:%M")
    return (
        "<h1>🌳 דוח עץ מוצר (מקוצר)</h1>"
        '<div class="meta-card">'
        f'<p><span class="muted">📅 תאריך הפקה:</span> <b>{ts}</b></p>'
        f'<p><span class="muted">📄 שרטוטים שהועלו:</span> <b>{n_drawings}</b> · '
        f'<span class="muted">פריטים בעץ:</span> <b>{n_rows}</b></p>'
        '</div>'
    )


def build_tree_pdf(
    drawings: list[dict],
    relationships: dict | None,
    out_path: Path,
) -> Path:
    """בונה דוח PDF מקוצר של עץ המוצר בלבד.

    כולל:
      • שער קצר
      • טבלת עץ (רמה, P/N, Drawing, תיאור, כמות, חומר)
      • סכמה ויזואלית מקננת
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    rows = _flatten_tree_rows(drawings, relationships)

    page_w, page_h = fitz.paper_size("a4")
    margin = 36
    mediabox = fitz.Rect(0, 0, page_w, page_h)
    where = fitz.Rect(margin, margin, page_w - margin, page_h - margin)

    summary = ""
    rel_summary = ((relationships or {}).get("summary_he") or "").strip()
    if rel_summary:
        summary = f'<div class="summary">📋 {_h(rel_summary)}</div>'

    sections = [
        _wrap_rtl_tree(
            _tree_cover_html(len(drawings or []), len(rows))
            + summary
            + "<h2>📋 טבלת עץ מוצר</h2>"
            + _tree_table_html(rows)
        ),
        _wrap_rtl_tree(
            "<h2>🗂️ סכמת עץ מוצר</h2>"
            + _tree_schematic_html(rows)
        ),
    ]

    writer = fitz.DocumentWriter(str(out_path))
    try:
        for html_content in sections:
            story = fitz.Story(html=html_content)
            more = 1
            while more:
                dev = writer.begin_page(mediabox)
                more, _filled = story.place(where)
                story.draw(dev)
                writer.end_page()
    finally:
        writer.close()

    return out_path


def build_tree_excel(
    drawings: list[dict],
    relationships: dict | None,
    out_path: Path,
) -> Path:
    """שומר את עץ המוצר כקובץ Excel.

    גיליון יחיד 'Tree': רמה · P/N · Drawing · תיאור · כמות · חומר · הועלה?
    """
    import pandas as pd  # ייבוא עצל

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    rows = _flatten_tree_rows(drawings, relationships)
    idx = _build_drawing_index(drawings)

    excel_rows = []
    for r in rows:
        pn = (r.get("part_number") or "").strip()
        excel_rows.append({
            "רמה": r.get("level", 0),
            "P/N": pn,
            "Drawing": r.get("drawing_number", ""),
            "תיאור": r.get("description", ""),
            "כמות": r.get("qty", ""),
            "חומר": r.get("material", ""),
            "הועלה?": "כן" if pn and pn.upper() in idx else "לא",
        })

    cols = ["רמה", "P/N", "Drawing", "תיאור", "כמות", "חומר", "הועלה?"]
    df = pd.DataFrame(excel_rows, columns=cols)

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Tree", index=False)
        ws = writer.sheets["Tree"]
        widths = {"A": 6, "B": 22, "C": 18, "D": 38, "E": 8, "F": 22, "G": 9}
        for col, w in widths.items():
            ws.column_dimensions[col].width = w
        ws.sheet_view.rightToLeft = True

    return out_path
