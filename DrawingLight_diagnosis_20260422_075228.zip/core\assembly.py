"""
Assembly Mode — חילוץ מלא של מספר שרטוטים וניתוח קשרים בין מכלולים.

מודול זה נפרד לחלוטין מ-core/extractor.py כדי לא להשפיע על המצב הקיים
של ניתוח שרטוט בודד. הוא משתמש ב-pipeline משלו עם prompts ייעודיים
מתוך core/assembly_prompts.py.

שלבים:
  1. extract_assembly_drawing(pdf_path) — חילוץ מלא של שרטוט בודד (ללא מאסטרים).
  2. analyze_relationships(results) — ניתוח קשרי אבא/בן בין כל השרטוטים שנותחו.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from core.azure_client import get_client, get_deployment, is_reasoning_model
from core.pdf_utils import pdf_to_images, image_file_to_b64
from core.cost_tracker import DrawingCostTracker, calculate_cost
from core.ocr_fallback import is_ocr_available, extract_text_from_pdf, build_enhanced_prompt
from core.assembly_prompts import (
    ASSEMBLY_STAGE_1_PROMPT,
    ASSEMBLY_STAGE_2_PROMPT,
    ASSEMBLY_RELATIONSHIPS_PROMPT_TEMPLATE,
    ASSEMBLY_OVERVIEW_IMAGE_PROMPT,
)

logger = logging.getLogger(__name__)


# ───────────────────────────────────────────────────────────────
# עזרי קריאה למודל (עצמאיים — לא נשענים על הפרטיים של extractor.py)
# ───────────────────────────────────────────────────────────────
def _build_kwargs(max_tokens: int, temperature: float, json_mode: bool) -> dict:
    kwargs: dict = {}
    if is_reasoning_model():
        kwargs["max_completion_tokens"] = max_tokens
    else:
        kwargs["max_tokens"] = max_tokens
        kwargs["temperature"] = temperature
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}
    return kwargs


def _strip_json_fences(raw: str) -> str:
    raw = (raw or "").strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()
    return raw


def _call_vision(client, deployment: str, prompt: str, images_b64: list[str]):
    content = [{"type": "text", "text": prompt}]
    for img_b64 in images_b64:
        content.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:image/png;base64,{img_b64}",
                "detail": "high",
            },
        })
    budget = 16000 if is_reasoning_model() else 6000
    response = client.chat.completions.create(
        model=deployment,
        messages=[{"role": "user", "content": content}],
        **_build_kwargs(max_tokens=budget, temperature=0.1, json_mode=True),
    )
    raw = _strip_json_fences(response.choices[0].message.content or "")
    if not raw:
        return {}, response.usage
    try:
        return json.loads(raw), response.usage
    except json.JSONDecodeError as exc:
        logger.warning("Assembly JSON parse failed: %s — head: %s", exc, raw[:200])
        return {}, response.usage


def _call_text_json(client, deployment: str, prompt: str):
    """קריאה טקסטואלית שמחזירה JSON (לשלב ניתוח הקשרים)."""
    budget = 8000 if is_reasoning_model() else 3000
    response = client.chat.completions.create(
        model=deployment,
        messages=[{"role": "user", "content": prompt}],
        **_build_kwargs(max_tokens=budget, temperature=0.2, json_mode=True),
    )
    raw = _strip_json_fences(response.choices[0].message.content or "")
    if not raw:
        return {}, response.usage
    try:
        return json.loads(raw), response.usage
    except json.JSONDecodeError as exc:
        logger.warning("Relationships JSON parse failed: %s — head: %s", exc, raw[:200])
        return {"summary_he": raw, "assemblies": [], "orphans": [],
                "missing_children": [], "warnings_he": []}, response.usage


# ───────────────────────────────────────────────────────────────
# 1. חילוץ שרטוט בודד במצב Assembly
# ───────────────────────────────────────────────────────────────
def extract_assembly_drawing(pdf_path: str | Path) -> dict:
    """חילוץ מלא של שרטוט (כולל עיבוד שבבי) — ללא התאמת מאסטרים.

    מחזיר dict עם:
      part_number, revision, drawing_number, customer, material, quantity,
      assembly_role, bom_items,
      machining_processes, coating_processes, painting_processes,
      inspection_processes, final_approval, additional_processes,
      packaging_notes, standards, notes,
      source_filename, _cost_info, _ocr_used.
    """
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(f"קובץ לא נמצא: {pdf_path}")

    logger.info(f"[Assembly] מעבד שרטוט: {pdf_path.name}")
    images = pdf_to_images(pdf_path, dpi=300)

    client = get_client()
    deployment = get_deployment()
    tracker = DrawingCostTracker(pdf_path.name)

    # OCR מוקדם
    ocr_text = ""
    ocr_used = False
    if is_ocr_available():
        try:
            ocr_text = extract_text_from_pdf(pdf_path)
            ocr_used = bool(ocr_text.strip())
        except Exception as exc:
            logger.warning("[Assembly] OCR נכשל: %s", exc)

    # Stage 1
    s1_prompt = (
        build_enhanced_prompt(ASSEMBLY_STAGE_1_PROMPT, ocr_text)
        if ocr_text else ASSEMBLY_STAGE_1_PROMPT
    )
    stage1, usage1 = _call_vision(client, deployment, s1_prompt, images)
    tracker.add_stage("assembly_stage_1_basic", calculate_cost(usage1, deployment))

    # Stage 2 — תכולה מלאה
    s2_prompt = (
        build_enhanced_prompt(ASSEMBLY_STAGE_2_PROMPT, ocr_text)
        if ocr_text else ASSEMBLY_STAGE_2_PROMPT
    )
    stage2, usage2 = _call_vision(client, deployment, s2_prompt, images)
    tracker.add_stage("assembly_stage_2_full", calculate_cost(usage2, deployment))

    # Fallback ל-part_number כמו ב-extractor הרגיל
    if not (stage1.get("part_number") or "").strip():
        dn = (stage1.get("drawing_number") or "").strip()
        if dn:
            stage1["part_number"] = dn

    result = {
        **stage1,
        **stage2,
        "source_filename": pdf_path.name,
        "_cost_info": tracker.summary(),
        "_ocr_used": ocr_used,
    }
    tracker.save_to_log()
    logger.info(
        f"[Assembly] ✅ {pdf_path.name} | עלות: ${tracker.total_cost():.4f}"
    )
    return result


# ───────────────────────────────────────────────────────────────
# 1b. חילוץ תמונת תרשים מכלול (Exploded View / Assembly Overview)
# ───────────────────────────────────────────────────────────────
def extract_assembly_overview_image(image_path: str | Path) -> dict:
    """מנתח תמונת תרשים מכלול (PNG/JPG) ומחזיר אותה כ"שרטוט" במבנה זהה
    ל-extract_assembly_drawing, עם assembly_role="Assembly Overview Image".

    התמונה משמשת כמפת-מבנה לניתוח קשרי אבא/בן — היא מכילה בועיות מספור
    (Find Numbers) שמחברות בין החלקים, גם אם ה-PN המדויק לא רשום בה.
    אין OCR (התמונה לרוב גרפית), אין Stage2 (אין title block ותהליכים).
    """
    image_path = Path(image_path)
    if not image_path.exists():
        raise FileNotFoundError(f"קובץ לא נמצא: {image_path}")

    logger.info(f"[Assembly] מעבד תרשים מכלול (תמונה): {image_path.name}")
    images = image_file_to_b64(image_path)

    client = get_client()
    deployment = get_deployment()
    tracker = DrawingCostTracker(image_path.name)

    data, usage = _call_vision(client, deployment, ASSEMBLY_OVERVIEW_IMAGE_PROMPT, images)
    tracker.add_stage("assembly_overview_image", calculate_cost(usage, deployment))

    # נירמול שדות חסרים כדי להישאר תואם למבנה של שרטוט רגיל
    data.setdefault("part_number", "")
    data.setdefault("drawing_number", "")
    data.setdefault("revision", "")
    data.setdefault("customer", "")
    data.setdefault("material", "")
    data.setdefault("quantity", "")
    data["assembly_role"] = "Assembly Overview Image"
    data.setdefault("bom_items", [])
    for k in ("machining_processes", "coating_processes", "painting_processes",
              "inspection_processes", "additional_processes", "standards"):
        data.setdefault(k, [])
    data.setdefault("final_approval", "")
    data.setdefault("packaging_notes", "")
    data.setdefault("notes", "")

    # אם לא הצלחנו לחלץ PN — נשתמש בשם הקובץ כמזהה
    if not (data.get("part_number") or "").strip():
        data["part_number"] = image_path.stem

    data["source_filename"] = image_path.name
    data["_cost_info"] = tracker.summary()
    data["_ocr_used"] = False
    data["_is_overview_image"] = True

    tracker.save_to_log()
    logger.info(
        f"[Assembly] ✅ תרשים מכלול {image_path.name} | "
        f"בועיות={len(data.get('bom_items') or [])} | "
        f"עלות: ${tracker.total_cost():.4f}"
    )
    return data


# ───────────────────────────────────────────────────────────────
# 2. ניתוח קשרי אבא/בן בין שרטוטים שנותחו
# ───────────────────────────────────────────────────────────────
def _summarize_drawing_for_prompt(d: dict, idx: int) -> str:
    """דוחס שרטוט לטקסט קצר בשביל ה-prompt של ניתוח הקשרים."""
    pn = d.get("part_number") or "?"
    dn = d.get("drawing_number") or "?"
    rev = d.get("revision") or "?"
    cust = d.get("customer") or "?"
    mat = d.get("material") or "?"
    role = d.get("assembly_role") or "?"
    qty = d.get("quantity") or ""
    src = d.get("source_filename") or ""

    # תהליכים מרוכזים
    procs = []
    for c in d.get("coating_processes", []) or []:
        if isinstance(c, dict):
            t = c.get("type_he") or c.get("type") or c.get("name") or ""
            s = c.get("standard") or ""
            procs.append(f"{t} ({s})".strip())
    for p in d.get("painting_processes", []) or []:
        if isinstance(p, dict):
            t = p.get("type_he") or p.get("type") or p.get("name") or ""
            s = p.get("standard") or ""
            procs.append(f"{t} ({s})".strip())

    bom_items = d.get("bom_items") or []
    bom_text = ""
    if bom_items:
        lines = []
        for it in bom_items:
            if isinstance(it, dict):
                lines.append(
                    f"      - item {it.get('item_no','?')}: "
                    f"P/N={it.get('part_number','?')} | "
                    f"qty={it.get('qty','?')} | desc={it.get('description','')}"
                )
        bom_text = "\n   BOM:\n" + "\n".join(lines)

    return (
        f"#{idx}  file={src}\n"
        f"   part_number={pn} | drawing_number={dn} | rev={rev} | customer={cust}\n"
        f"   material={mat}\n"
        f"   role={role} | quantity={qty}\n"
        f"   processes={'; '.join(procs) if procs else '—'}"
        f"{bom_text}"
    )


def analyze_relationships(results: list[dict]) -> dict:
    """מריץ AI על כל השרטוטים יחד ומחזיר ניתוח קשרי אבא/בן.

    מחזיר dict:
      {
        "summary_he": str,
        "assemblies": [{parent_part_number, parent_drawing_number, children:[...]}],
        "orphans": [...],
        "missing_children": [...],
        "warnings_he": [...],
        "_cost_info": {...}
      }
    """
    if not results:
        return {
            "summary_he": "לא הועלו שרטוטים.",
            "assemblies": [], "orphans": [],
            "missing_children": [], "warnings_he": [],
            "_cost_info": {},
        }

    drawings_text = "\n\n".join(
        _summarize_drawing_for_prompt(d, i + 1) for i, d in enumerate(results)
    )
    prompt = ASSEMBLY_RELATIONSHIPS_PROMPT_TEMPLATE.format(
        drawings_data=drawings_text
    )

    client = get_client()
    deployment = get_deployment()
    tracker = DrawingCostTracker("__assembly_relationships__")
    analysis, usage = _call_text_json(client, deployment, prompt)
    tracker.add_stage("assembly_relationships", calculate_cost(usage, deployment))

    # ודא מבנה תקין
    analysis.setdefault("summary_he", "")
    analysis.setdefault("assemblies", [])
    analysis.setdefault("orphans", [])
    analysis.setdefault("missing_children", [])
    analysis.setdefault("warnings_he", [])
    analysis["_cost_info"] = tracker.summary()
    tracker.save_to_log()
    logger.info(
        f"[Assembly] ניתוח קשרים הושלם | עלות: ${tracker.total_cost():.4f}"
    )
    return analysis
