"""
UI של מצב 'מכלולים מרובים'.

מודול נפרד מ-app.py כדי שהקוד של המצב הקיים (שרטוט בודד) לא ישתנה.
מופעל מ-app.py באמצעות render_assembly_mode() כשהמשתמש בוחר במצב הזה.
"""
from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

import streamlit as st

from core.assembly import (
    extract_assembly_drawing,
    extract_assembly_overview_image,
    analyze_relationships,
)
from storage.save_handler import save_to_json
from storage.pdf_report import build_assembly_pdf, build_tree_pdf, build_tree_excel

logger = logging.getLogger(__name__)

_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp"}


def _init_state():
    if "asm_results" not in st.session_state:
        st.session_state["asm_results"] = []  # list[dict]
    if "asm_index" not in st.session_state:
        st.session_state["asm_index"] = 0
    if "asm_relationships" not in st.session_state:
        st.session_state["asm_relationships"] = None


def _process_pdf(uploaded_file, output_dir: Path) -> dict | None:
    """מנתב כל קובץ שהועלה — PDF לחילוץ רגיל, תמונה לניתוח תרשים-מכלול."""
    suffix = Path(uploaded_file.name).suffix.lower()
    temp_path = output_dir / f"_asm_temp_{uploaded_file.name}"
    with open(temp_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    try:
        if suffix in _IMAGE_SUFFIXES:
            return extract_assembly_overview_image(temp_path)
        return extract_assembly_drawing(temp_path)
    except Exception as exc:
        logger.exception("Assembly extract failed for %s", uploaded_file.name)
        st.error(f"❌ שגיאה ב-{uploaded_file.name}: {exc}")
        return None
    finally:
        if temp_path.exists():
            temp_path.unlink()


def _render_drawing_card(d: dict):
    """תצוגה מלאה של שרטוט בודד במצב מכלולים."""
    pn = d.get("part_number") or "—"
    dn = d.get("drawing_number") or "—"
    rev = d.get("revision") or "—"
    cust = d.get("customer") or "—"
    mat = d.get("material") or "—"
    qty = d.get("quantity") or "—"
    role = d.get("assembly_role") or "—"

    st.markdown(
        f'<div dir="rtl" style="unicode-bidi:plaintext; text-align:right; '
        f'background:linear-gradient(135deg,#eef5ff 0%,#e8f5e9 100%); '
        f'border:2px solid #0d6efd; border-radius:0.7em; padding:1em 1.2em; '
        f'margin-bottom:1em; font-size:0.95em; line-height:1.7;">'
        f'<div style="font-size:1.1em; font-weight:700; color:#0d6efd; '
        f'margin-bottom:0.5em; border-bottom:1px solid #cfe2ff; padding-bottom:0.3em;">'
        f'🎯 פרטי השרטוט</div>'
        f'<div><span style="color:#6c757d;">פריט:</span> <b>{pn}</b> &nbsp;·&nbsp; '
        f'<span style="color:#6c757d;">שרטוט:</span> <b>{dn}</b> &nbsp;·&nbsp; '
        f'<span style="color:#6c757d;">גרסה:</span> <b>{rev}</b> &nbsp;·&nbsp; '
        f'<span style="color:#6c757d;">לקוח:</span> <b>{cust}</b></div>'
        f'<div style="margin-top:0.4em;"><span style="color:#6c757d;">חומר:</span> <b>{mat}</b> '
        f'&nbsp;·&nbsp; <span style="color:#6c757d;">תפקיד:</span> <b>{role}</b> '
        f'&nbsp;·&nbsp; <span style="color:#6c757d;">כמות:</span> <b>{qty}</b></div>'
        f'</div>',
        unsafe_allow_html=True,
    )

    # ─── BOM (אם קיים) ───
    bom = d.get("bom_items") or []
    if bom:
        st.markdown("#### 📋 טבלת חלקים (BOM)")
        rows = []
        for it in bom:
            if isinstance(it, dict):
                rows.append({
                    "Item": it.get("item_no", ""),
                    "Part Number": it.get("part_number", ""),
                    "Description": it.get("description", ""),
                    "Qty": it.get("qty", ""),
                })
        if rows:
            st.dataframe(rows, use_container_width=True, hide_index=True)

    # ─── Helper להצגת שלב כללי ───
    def _render_step_block(title_he: str, icon: str, items: list,
                            keys=("step_no", "name_en", "name_he", "details")):
        if not items:
            return
        st.markdown(f"#### {icon} {title_he}")
        rows = []
        for it in items:
            if not isinstance(it, dict):
                rows.append({"שלב": "", "אנגלית": str(it), "עברית": "", "פרטים": ""})
                continue
            rows.append({
                "שלב": it.get(keys[0], ""),
                "אנגלית": it.get(keys[1], ""),
                "עברית": it.get(keys[2], ""),
                "פרטים": it.get(keys[3], ""),
            })
        st.dataframe(rows, use_container_width=True, hide_index=True)

    # ─── תהליכים בסדר העבודה ───
    _render_step_block("עיבוד שבבי", "🔧", d.get("machining_processes") or [])

    coatings = d.get("coating_processes") or []
    if coatings:
        st.markdown("#### 🎨 ציפויים / טיפול שטח")
        rows = []
        for c in coatings:
            if isinstance(c, dict):
                rows.append({
                    "שלב": c.get("step_no", ""),
                    "סוג (HE)": c.get("type_he", ""),
                    "סוג (EN)": c.get("type", ""),
                    "תיאור": c.get("name", ""),
                    "תקן": c.get("standard", ""),
                    "עובי": c.get("thickness", ""),
                    "RoHS": "✓" if c.get("rohs") else "",
                })
        st.dataframe(rows, use_container_width=True, hide_index=True)

    paintings = d.get("painting_processes") or []
    if paintings:
        st.markdown("#### 🖌️ צביעות")
        rows = []
        for p in paintings:
            if isinstance(p, dict):
                rows.append({
                    "שלב": p.get("step_no", ""),
                    "סוג (HE)": p.get("type_he", ""),
                    "סוג (EN)": p.get("type", ""),
                    "תיאור": p.get("name", ""),
                    "תקן": p.get("standard", ""),
                    "עובי": p.get("thickness", ""),
                    "RoHS": "✓" if p.get("rohs") else "",
                })
        st.dataframe(rows, use_container_width=True, hide_index=True)

    _render_step_block("בדיקות", "🔍", d.get("inspection_processes") or [])
    _render_step_block("אישור סופי", "✅", d.get("final_approval") or [])

    add = d.get("additional_processes") or []
    if add:
        st.markdown("#### 🛠️ תהליכים מלווים")
        rows = []
        for a in add:
            if isinstance(a, dict):
                rows.append({"אנגלית": a.get("name_en", ""), "עברית": a.get("name_he", "")})
        if rows:
            st.dataframe(rows, use_container_width=True, hide_index=True)

    # ─── תקנים ───
    stds = d.get("standards") or []
    if stds:
        st.markdown("#### 📜 כל התקנים שמופיעים בשרטוט")
        st.markdown(" &nbsp;·&nbsp; ".join(f"`{s}`" for s in stds))

    # ─── אריזה ───
    pkg = d.get("packaging_notes") or {}
    if isinstance(pkg, dict) and (pkg.get("he") or pkg.get("en")):
        st.markdown("#### 📦 אריזה")
        if pkg.get("he"):
            st.markdown(
                f'<div dir="rtl" style="unicode-bidi:plaintext; background:#fff3cd; '
                f'color:#664d03; padding:0.6em 0.9em; border-radius:0.4em; margin-bottom:0.4em;">'
                f'🇮🇱 {pkg["he"]}</div>',
                unsafe_allow_html=True,
            )
        if pkg.get("en"):
            st.markdown(
                f'<div dir="ltr" style="background:#fff3cd; color:#664d03; '
                f'padding:0.6em 0.9em; border-radius:0.4em;">🇬🇧 {pkg["en"]}</div>',
                unsafe_allow_html=True,
            )

    # ─── הערות ───
    notes = (d.get("notes") or "").strip()
    if notes:
        with st.expander("📝 הערות השרטוט (NOTES)", expanded=False):
            st.info(notes)

    with st.expander("📄 JSON מלא"):
        st.json({k: v for k, v in d.items() if not k.startswith("_")})


def _render_relationships(rel: dict):
    """תצוגת ניתוח קשרי אבא/בן בין השרטוטים."""
    st.markdown("## 🔗 ניתוח קשרי המכלול")

    summary = (rel.get("summary_he") or "").strip()
    if summary:
        st.markdown(
            f'<div dir="rtl" style="unicode-bidi:plaintext; background:#d4edda; '
            f'color:#155724; padding:0.7em 1em; border-radius:0.5em; '
            f'margin:0.5em 0 1em 0; line-height:1.7;">📋 <b>סיכום:</b><br>{summary}</div>',
            unsafe_allow_html=True,
        )

    asms = rel.get("assemblies") or []
    if asms:
        st.markdown("### 🧩 מכלולים שזוהו")
        for a in asms:
            ppn = a.get("parent_part_number") or "—"
            pdn = a.get("parent_drawing_number") or "—"
            kids = a.get("children") or []
            with st.expander(f"📦 מכלול: P/N={ppn}  ·  DWG={pdn}  ·  {len(kids)} חלקים",
                             expanded=True):
                if kids:
                    rows = []
                    for k in kids:
                        if isinstance(k, dict):
                            rows.append({
                                "P/N": k.get("part_number", ""),
                                "Drawing": k.get("drawing_number", ""),
                                "Description": k.get("description", ""),
                                "Qty": k.get("qty", ""),
                                "הועלה?": "✓" if k.get("found_in_uploaded_files") else "✗",
                            })
                    st.dataframe(rows, use_container_width=True, hide_index=True)
                else:
                    st.caption("אין חלקים")

    orphans = rel.get("orphans") or []
    if orphans:
        st.markdown("### 🪙 שרטוטים ללא הורה")
        rows = []
        for o in orphans:
            if isinstance(o, dict):
                rows.append({
                    "P/N": o.get("part_number", ""),
                    "Drawing": o.get("drawing_number", ""),
                    "סיבה": o.get("reason_he", ""),
                })
        st.dataframe(rows, use_container_width=True, hide_index=True)

    missing = rel.get("missing_children") or []
    if missing:
        st.markdown("### ⚠️ חלקים שמופיעים ב-BOM אך לא הועלו כשרטוט")
        rows = []
        for m in missing:
            if isinstance(m, dict):
                rows.append({
                    "P/N": m.get("part_number", ""),
                    "Description": m.get("description", ""),
                    "Qty": m.get("qty", ""),
                    "נדרש ע\"י": m.get("needed_by_he", ""),
                })
        st.dataframe(rows, use_container_width=True, hide_index=True)

    warnings = rel.get("warnings_he") or []
    if warnings:
        st.markdown("### 💡 הערות / אזהרות")
        for w in warnings:
            st.warning(w)


# ═══════════════════════════════════════════════════════════════
# נקודת כניסה
# ═══════════════════════════════════════════════════════════════
def render_assembly_mode(output_dir: Path):
    """מצייר את כל מסך מצב המכלולים."""
    _init_state()

    st.markdown("## 🧩 מצב מכלולים — ניתוח שרטוטים מרובים")
    st.caption("העלה מספר שרטוטים יחד · נתח אותם בנפרד · קבל ניתוח קשרים בסוף")

    # ─── 1. העלאת קבצים ───
    st.markdown("### 1️⃣ העלה שרטוטים PDF (ואופציונלית תרשים מכלול PNG/JPG)")
    files = st.file_uploader(
        "גרור שרטוטי PDF + תמונה אחת של תרשים-מכלול (Exploded View) — או לחץ לבחירה",
        type=["pdf", "png", "jpg", "jpeg", "webp"],
        accept_multiple_files=True,
        key="asm_uploader",
    )

    col_a, col_b = st.columns([3, 1])
    with col_a:
        do_analyze = st.button(
            f"🔍 נתח {len(files) if files else 0} שרטוטים",
            type="primary",
            disabled=not files,
            use_container_width=True,
        )
    with col_b:
        if st.button("🗑️ נקה", use_container_width=True):
            st.session_state["asm_results"] = []
            st.session_state["asm_index"] = 0
            st.session_state["asm_relationships"] = None
            st.rerun()

    # ─── 2. ניתוח ───
    if do_analyze and files:
        progress = st.progress(0.0, text="מתחיל ניתוח...")
        results: list[dict] = []
        for i, f in enumerate(files, 1):
            progress.progress(
                (i - 1) / len(files),
                text=f"🔄 מנתח {i}/{len(files)}: {f.name}",
            )
            res = _process_pdf(f, output_dir)
            if res is not None:
                results.append(res)
        progress.progress(1.0, text="✅ ניתוח הסתיים")
        # תמונת מכלול (Overview Image) תמיד ראשונה — היא מייצגת את כל
        # השרטוטים יחד, לא משנה באיזה סדר הועלתה.
        results.sort(key=lambda r: 0 if r.get("_is_overview_image") else 1)
        st.session_state["asm_results"] = results
        st.session_state["asm_index"] = 0
        st.session_state["asm_relationships"] = None  # נדרש מחדש
        st.success(f"✅ נותחו {len(results)} שרטוטים")

    results = st.session_state["asm_results"]
    if not results:
        st.info("📥 העלה שרטוטים ולחץ 'נתח' כדי להתחיל.")
        return

    # ─── 3. ניווט בין שרטוטים ───
    st.divider()
    st.markdown("### 2️⃣ דפדוף בין שרטוטים")

    n = len(results)
    idx = max(0, min(st.session_state["asm_index"], n - 1))

    def _goto(new_idx: int):
        """מעדכן את האינדקס. אסור לגעת ב-asm_jump כאן —
        ה-selectbox כבר נוצר באותה הרצה, וסנכרון מתבצע בראש ההרצה הבאה."""
        new_idx = max(0, min(new_idx, n - 1))
        st.session_state["asm_index"] = new_idx

    def _on_jump_change():
        st.session_state["asm_index"] = st.session_state["asm_jump"]

    # ודא שערך ה-selectbox מסונכרן עם asm_index לפני יצירת ה-widget
    if st.session_state.get("asm_jump") != idx:
        st.session_state["asm_jump"] = idx

    nav_a, nav_b, nav_c, nav_d, nav_e = st.columns([1, 1, 3, 1, 1])
    with nav_a:
        if st.button("⏮️ ראשון", use_container_width=True, disabled=idx == 0):
            _goto(0)
            st.rerun()
    with nav_b:
        if st.button("◀️ הקודם", use_container_width=True, disabled=idx == 0):
            _goto(idx - 1)
            st.rerun()
    with nav_c:
        labels = [
            f"{i+1}. {(r.get('part_number') or r.get('source_filename') or '?')[:40]}"
            for i, r in enumerate(results)
        ]
        st.selectbox(
            "קפוץ לשרטוט", options=list(range(n)),
            format_func=lambda i: labels[i],
            key="asm_jump",
            on_change=_on_jump_change,
            label_visibility="collapsed",
        )
    with nav_d:
        if st.button("▶️ הבא", use_container_width=True, disabled=idx == n - 1):
            _goto(idx + 1)
            st.rerun()
    with nav_e:
        if st.button("⏭️ אחרון", use_container_width=True, disabled=idx == n - 1):
            _goto(n - 1)
            st.rerun()

    st.caption(f"📄 מציג שרטוט **{idx + 1}** מתוך **{n}** · "
               f"`{results[idx].get('source_filename', '')}`")

    # ─── 4. תצוגה מלאה של השרטוט הנבחר ───
    _render_drawing_card(results[idx])

    # ─── 5. ניתוח קשרים ───
    st.divider()
    st.markdown("### 3️⃣ ניתוח קשרי המכלול")

    rel = st.session_state["asm_relationships"]
    col_r1, col_r2, col_r3 = st.columns([2, 1, 1])
    with col_r1:
        if st.button("🔗 נתח קשרי אבא/בן בין כל השרטוטים",
                     type="primary", use_container_width=True):
            with st.spinner("🔄 שולח את כל השרטוטים לניתוח..."):
                try:
                    rel = analyze_relationships(results)
                    st.session_state["asm_relationships"] = rel
                except Exception as exc:
                    logger.exception("Relationships analysis failed")
                    st.error(f"❌ שגיאה בניתוח קשרים: {exc}")
                    rel = None
    with col_r2:
        if rel and st.button("💾 שמור JSON", use_container_width=True):
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            payload = {"drawings": results, "relationships": rel}
            path = save_to_json(payload, output_dir / f"_assembly_{ts}.json")
            st.success(f"נשמר: `{path.name}`")
    with col_r3:
        # כפתור הוצאת דוח PDF — לא מריץ ניתוח מחדש!
        # אם הקשרים כבר נותחו → ייכללו בדוח. אחרת הדוח יוצא בלעדיהם.
        if st.button("📕 הורד דוח PDF", use_container_width=True,
                     type="secondary"):
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            pdf_path = output_dir / f"_assembly_report_{ts}.pdf"
            try:
                with st.spinner("📄 מייצר דוח PDF..."):
                    build_assembly_pdf(results, rel, pdf_path)
                st.session_state["asm_pdf_path"] = str(pdf_path)
                if rel is None:
                    st.info("ℹ️ הדוח הופק ללא ניתוח קשרים "
                            "(לא הופעל). לחץ '🔗 נתח קשרי אבא/בן' "
                            "ואחר כך 'הורד דוח PDF' שוב כדי לכלול אותם.")
                st.success(f"דוח נוצר: `{pdf_path.name}`")
            except Exception as exc:
                logger.exception("PDF report failed")
                st.error(f"❌ שגיאה ביצירת PDF: {exc}")

    # ─── דוח עץ מוצר מקוצר (טבלה + סכמה) ───
    if st.button("🌳 הורד דוח עץ מוצר (מקוצר)", use_container_width=True,
                 type="secondary"):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        tree_path = output_dir / f"_assembly_tree_{ts}.pdf"
        try:
            with st.spinner("📄 מייצר דוח עץ מוצר..."):
                build_tree_pdf(results, rel, tree_path)
            st.session_state["asm_tree_pdf_path"] = str(tree_path)
            if rel is None:
                st.info("ℹ️ הדוח הופק ללא ניתוח קשרים — מציג רשימה שטוחה. "
                        "לחץ '🔗 נתח קשרי אבא/בן' לעץ מובנה.")
            st.success(f"דוח עץ נוצר: `{tree_path.name}`")
        except Exception as exc:
            logger.exception("Tree PDF report failed")
            st.error(f"❌ שגיאה ביצירת דוח עץ: {exc}")

    tree_pdf_str = st.session_state.get("asm_tree_pdf_path")
    if tree_pdf_str and Path(tree_pdf_str).exists():
        with open(tree_pdf_str, "rb") as fh:
            st.download_button(
                label=f"⬇️ הורד {Path(tree_pdf_str).name}",
                data=fh.read(),
                file_name=Path(tree_pdf_str).name,
                mime="application/pdf",
                use_container_width=True,
                key="dl_tree_pdf",
            )

    # ─── דוח עץ מוצר ל-Excel ───
    if st.button("📊 הורד עץ מוצר ל-Excel", use_container_width=True,
                 type="secondary"):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        xlsx_path = output_dir / f"_assembly_tree_{ts}.xlsx"
        try:
            with st.spinner("📄 מייצר Excel של עץ המוצר..."):
                build_tree_excel(results, rel, xlsx_path)
            st.session_state["asm_tree_xlsx_path"] = str(xlsx_path)
            st.success(f"קובץ נוצר: `{xlsx_path.name}`")
        except Exception as exc:
            logger.exception("Tree Excel export failed")
            st.error(f"❌ שגיאה ביצירת Excel: {exc}")

    tree_xlsx_str = st.session_state.get("asm_tree_xlsx_path")
    if tree_xlsx_str and Path(tree_xlsx_str).exists():
        with open(tree_xlsx_str, "rb") as fh:
            st.download_button(
                label=f"⬇️ הורד {Path(tree_xlsx_str).name}",
                data=fh.read(),
                file_name=Path(tree_xlsx_str).name,
                mime="application/vnd.openxmlformats-officedocument."
                     "spreadsheetml.sheet",
                use_container_width=True,
                key="dl_tree_xlsx",
            )

    # ─── כפתור הורדה לדפדפן (מופיע אחרי שהקובץ נוצר) ───
    pdf_path_str = st.session_state.get("asm_pdf_path")
    if pdf_path_str and Path(pdf_path_str).exists():
        with open(pdf_path_str, "rb") as fh:
            st.download_button(
                label=f"⬇️ הורד {Path(pdf_path_str).name}",
                data=fh.read(),
                file_name=Path(pdf_path_str).name,
                mime="application/pdf",
                use_container_width=True,
            )

    if rel:
        _render_relationships(rel)
