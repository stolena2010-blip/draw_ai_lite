# 📐 DrawingAI Lite

אפליקציית Streamlit לניתוח שרטוטים טכניים (PDF) באמצעות Azure OpenAI Vision / Reasoning.

## תכולה

### 🔍 מצב 'שרטוט בודד'
- העלאת PDF יחיד → חילוץ אוטומטי של שדות טכניים (P/N, revision, customer, material, תהליכי ציפוי/צביעה, תקנים, הערות)
- סיכום בעברית
- **התאמה למאסטרים** מ-Masters.xlsx (Top-3 לכל ציפוי, ציון 0-150)
- OCR Fallback אוטומטי (Tesseract) כשה-Vision חלש
- שמירת תוצאות ל-JSON / Excel

### 🧩 מצב 'מכלולים מרובים'
- העלאת מספר PDFים יחד **או** תמונת Exploded View (PNG/JPG/WEBP)
- ניתוח כל שרטוט בנפרד + ניתוח קשרי אבא/בן בין השרטוטים
- תמונת מכלול ממוינת אוטומטית לראש (לא משנה סדר ההעלאה)
- ייצוא:
  - 📕 דוח PDF מלא (RTL עברית)
  - 🌳 דוח עץ מוצר מקוצר (טבלה + סכמה ויזואלית)
  - 📊 עץ מוצר ל-Excel
  - 💾 JSON מאוחד

### 💰 מעקב עלויות
- כל קריאת API נמדדת ונשמרת ב-`output/costs.jsonl`
- תוסף Azure ניתן להגדרה דרך `AZURE_SURCHARGE` ב-`.env`

## התקנה

### 1. דרישות מוקדמות
- Python 3.10+ (מומלץ 3.13)
- חשבון Azure OpenAI עם deployment של `gpt-4o` או `gpt-5.4`
- (אופציונלי) [Tesseract OCR](https://github.com/UB-Mannheim/tesseract/wiki) — לפעולת OCR Fallback (התקן גם חבילת שפה עברית)

### 2. venv + חבילות
```powershell
cd C:\DrawingLight
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

### 3. הגדרת Azure
```powershell
Copy-Item .env.example .env
# ערוך .env ומלא את הפרטים שלך
```

## הרצה

```powershell
.\.venv\Scripts\Activate.ps1
streamlit run app.py
```

או הרצה מהירה: `Run_Web.bat`

הדפדפן יפתח ב-http://localhost:8501

## בדיקות

```powershell
.\.venv\Scripts\Activate.ps1
pytest tests/ -v
```

## מבנה

```
DrawingLight/
├── app.py                  ← Streamlit entry (מצב 'שרטוט בודד')
├── ui_assembly.py          ← מסך 'מכלולים מרובים'
├── core/
│   ├── azure_client.py     ← Azure OpenAI wrapper
│   ├── pdf_utils.py        ← PDF/Image → base64
│   ├── prompts.py          ← Stage 1/2/3 prompts (בודד)
│   ├── extractor.py        ← pipeline ראשי (בודד)
│   ├── master_matcher.py   ← התאמה למאסטרים (1239 פריטים)
│   ├── cost_tracker.py     ← מעקב עלויות
│   ├── ocr_fallback.py     ← Tesseract fallback
│   ├── assembly_prompts.py ← פרומפטים למצב מכלולים + Overview Image
│   └── assembly.py         ← pipeline מכלולים + ניתוח קשרים
├── storage/
│   ├── save_handler.py     ← JSON + Excel
│   └── pdf_report.py       ← דוחות PDF (מלא + עץ מוצר) + Excel עץ
├── tests/
│   └── test_master_matcher.py  ← 26 בדיקות
├── output/                 ← תוצאות + costs.jsonl
├── Masters.xlsx            ← מאגר ציפויים (חובה למצב 'בודד')
├── requirements.txt
├── .env.example
├── PROJECT_OVERVIEW.md     ← סקירה מפורטת
└── CHANGELOG.md            ← שינויים אחרונים
```

ראה [PROJECT_OVERVIEW.md](PROJECT_OVERVIEW.md) לסקירה טכנית מלאה.

