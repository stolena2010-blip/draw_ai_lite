"""
שמירת תוצאות ל-JSON ו-Excel.
"""
import json
from datetime import datetime
from pathlib import Path

import pandas as pd


def save_to_json(data: dict, path: Path) -> Path:
    """שמירה ל-JSON בפורמט קריא עם UTF-8 מלא."""
    path = Path(path)
    data_with_meta = {
        **data,
        "_saved_at": datetime.now().isoformat(),
    }
    path.write_text(
        json.dumps(data_with_meta, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )
    return path


def save_to_excel(data: dict, path: Path) -> Path:
    """שמירה ל-Excel — שורה אחת עם כל השדות."""
    path = Path(path)

    flat = {}
    for k, v in data.items():
        if isinstance(v, list):
            flat[k] = ", ".join(str(x) for x in v)
        elif isinstance(v, dict):
            flat[k] = json.dumps(v, ensure_ascii=False)
        else:
            flat[k] = v

    flat["_saved_at"] = datetime.now().isoformat()

    df = pd.DataFrame([flat])
    df.to_excel(path, index=False, engine="openpyxl")
    return path


def append_to_log(data: dict, log_path: Path = Path("output/history.jsonl")) -> None:
    """הוסף שורה ל-JSONL לתיעוד היסטורי."""
    log_path = Path(log_path)
    log_path.parent.mkdir(exist_ok=True)

    entry = {
        "timestamp": datetime.now().isoformat(),
        **data,
    }
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
