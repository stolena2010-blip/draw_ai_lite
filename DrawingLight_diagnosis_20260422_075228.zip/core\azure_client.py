﻿"""
Azure OpenAI client wrapper ג€” ׳×׳•׳׳ ׳‘-gpt-4o-vision (׳₪׳©׳•׳˜) ׳•׳‘-gpt-5.4 (reasoning).

׳׳§׳•׳¨׳•׳× ׳׳‘׳—׳™׳¨׳× ׳”׳׳•׳“׳ ׳”׳₪׳¢׳™׳ (׳׳₪׳™ ׳¡׳“׳¨ ׳¢׳“׳™׳₪׳•׳×):
  1. ׳”׳’׳“׳¨׳× runtime ג€” ׳§׳•׳‘׳¥ output/_runtime_settings.json (׳ ׳›׳×׳‘ ׳׳×׳₪׳¨׳™׳˜ ׳”׳”׳’׳“׳¨׳•׳× ׳‘-UI).
  2. ׳׳©׳×׳ ׳” ׳”׳¡׳‘׳™׳‘׳” ACTIVE_MODEL ׳׳×׳•׳ .env.

׳™׳© ׳’׳ ׳×׳׳™׳›׳” ׳‘-Fallback: ׳׳ ׳”׳§׳¨׳™׳׳” ׳׳׳•׳“׳ ׳”׳¨׳׳©׳™ ׳ ׳›׳©׳׳× ׳•׳”׳׳©׳×׳׳© ׳”׳₪׳¢׳™׳
׳׳× ׳”׳׳×׳’, ׳”׳§׳•׳“ ׳™׳ ׳¡׳” ׳׳•׳˜׳•׳׳˜׳™׳× ׳׳× ׳”׳׳•׳“׳ ׳”׳©׳ ׳™.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from openai import AzureOpenAI, OpenAI
from dotenv import load_dotenv

load_dotenv()

# ׳׳–׳”׳™ ׳׳•׳“׳׳™׳ ׳ ׳×׳׳›׳™׳
MODEL_GPT_4O = "gpt-4o-vision"
MODEL_GPT_5_4 = "gpt-5.4"
SUPPORTED_MODELS = (MODEL_GPT_4O, MODEL_GPT_5_4)

_RUNTIME_FILE = Path("output/_runtime_settings.json")


# ג”€ג”€ג”€ ׳”׳’׳“׳¨׳•׳× runtime (׳ ׳›׳×׳‘׳•׳× ׳¢"׳™ ׳×׳₪׳¨׳™׳˜ ׳”׳”׳’׳“׳¨׳•׳× ׳‘-UI) ג”€ג”€ג”€
def _load_runtime_settings() -> dict:
    if not _RUNTIME_FILE.exists():
        return {}
    try:
        return json.loads(_RUNTIME_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_runtime_settings(active_model: str | None = None,
                           fallback_enabled: bool | None = None) -> None:
    """׳©׳•׳׳¨ ׳”׳¢׳“׳₪׳•׳× ׳׳•׳“׳ ׳‘׳§׳•׳‘׳¥ runtime (׳׳ ׳ ׳•׳’׳¢ ׳‘-.env)."""
    cur = _load_runtime_settings()
    if active_model is not None:
        cur["active_model"] = active_model
    if fallback_enabled is not None:
        cur["fallback_enabled"] = bool(fallback_enabled)
    _RUNTIME_FILE.parent.mkdir(parents=True, exist_ok=True)
    _RUNTIME_FILE.write_text(
        json.dumps(cur, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def _active_model() -> str:
    rt = _load_runtime_settings()
    if rt.get("active_model"):
        return str(rt["active_model"]).strip()
    return os.getenv("ACTIVE_MODEL", MODEL_GPT_4O).strip()


def is_fallback_enabled() -> bool:
    """׳”׳׳ ׳׳”׳₪׳¢׳™׳ ׳׳•׳˜׳•׳׳˜׳™׳× ׳׳× ׳”׳׳•׳“׳ ׳”׳©׳ ׳™ ׳׳ ׳”׳¨׳׳©׳™ ׳ ׳›׳©׳."""
    rt = _load_runtime_settings()
    if "fallback_enabled" in rt:
        return bool(rt["fallback_enabled"])
    return os.getenv("MODEL_FALLBACK_ENABLED", "true").lower() == "true"


# ג”€ג”€ג”€ ׳–׳™׳”׳•׳™ ׳¡׳•׳’ ׳”׳׳•׳“׳ ג”€ג”€ג”€
def _is_gpt54(model: str) -> bool:
    m = (model or "").lower()
    return "5.4" in m or m == "gpt-5.4"


def is_reasoning_model(model: str | None = None) -> bool:
    """׳”׳׳ ׳”׳׳•׳“׳ ׳”׳₪׳¢׳™׳ ׳”׳•׳ reasoning (gpt-5.x / o-series)."""
    model = model or _active_model()
    if _is_gpt54(model):
        return os.getenv("MODEL_GPT_5_4_IS_REASONING", "true").lower() == "true"
    m = model.lower()
    return m.startswith("o1") or m.startswith("o3") or m.startswith("o4") or "gpt-5" in m


# ג”€ג”€ג”€ ׳™׳¦׳™׳¨׳× clients ג”€ג”€ג”€
def _build_client_gpt54():
    endpoint = os.getenv("MODEL_GPT_5_4_ENDPOINT", "").rstrip("/")
    api_key = os.getenv("MODEL_GPT_5_4_API_KEY")
    api_version = os.getenv("MODEL_GPT_5_4_API_VERSION", "2024-12-11-preview")
    if not endpoint or not api_key:
        raise ValueError(
            "׳—׳¡׳¨׳™׳ ׳׳©׳×׳ ׳™ ׳¡׳‘׳™׳‘׳” ׳-GPT-5.4: "
            "MODEL_GPT_5_4_ENDPOINT / MODEL_GPT_5_4_API_KEY"
        )
    return OpenAI(
        base_url=f"{endpoint}/openai/v1/",
        api_key=api_key,
        default_query={"api-version": api_version},
    )


def _build_client_gpt4o():
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview")
    if not endpoint or not api_key:
        raise ValueError(
            "׳—׳¡׳¨׳™׳ ׳׳©׳×׳ ׳™ ׳¡׳‘׳™׳‘׳”: AZURE_OPENAI_ENDPOINT / AZURE_OPENAI_API_KEY."
        )
    return AzureOpenAI(
        azure_endpoint=endpoint,
        api_key=api_key,
        api_version=api_version,
    )


def get_client(model: str | None = None):
    """׳׳—׳–׳™׳¨ client ׳©׳ ׳”׳׳•׳“׳ ׳”׳₪׳¢׳™׳ (׳׳• ׳©׳ ׳”׳׳•׳“׳ ׳”׳׳‘׳•׳§׳©)."""
    model = model or _active_model()
    if _is_gpt54(model):
        return _build_client_gpt54()
    return _build_client_gpt4o()


def get_deployment(model: str | None = None) -> str:
    """׳׳—׳–׳™׳¨ ׳׳× ׳©׳ ׳”-deployment ׳©׳ ׳”׳׳•׳“׳ ׳”׳₪׳¢׳™׳ (׳׳• ׳©׳ ׳”׳׳•׳“׳ ׳”׳׳‘׳•׳§׳©)."""
    model = model or _active_model()
    if _is_gpt54(model):
        return os.getenv("MODEL_GPT_5_4_DEPLOYMENT", "gpt-5.4")
    return os.getenv(
        "AZURE_DEPLOYMENT_NAME",
        os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o"),
    )


def get_fallback_model() -> str | None:
    """׳׳—׳–׳™׳¨ ׳׳× ׳”׳׳•׳“׳ ׳”׳©׳ ׳™ (׳׳ ׳₪׳¢׳™׳ gpt-5.4 ג†’ gpt-4o-vision ׳•׳׳”׳₪׳)."""
    primary = _active_model()
    if _is_gpt54(primary):
        return MODEL_GPT_4O
    return MODEL_GPT_5_4


def get_fallback_client_and_deployment():
    """׳׳—׳–׳™׳¨ (client, deployment, model_id) ׳©׳ ׳׳•׳“׳ ׳”-fallback, ׳׳• (None, None, None)."""
    if not is_fallback_enabled():
        return None, None, None
    fb = get_fallback_model()
    if not fb:
        return None, None, None
    try:
        return get_client(fb), get_deployment(fb), fb
    except Exception:
        return None, None, None
